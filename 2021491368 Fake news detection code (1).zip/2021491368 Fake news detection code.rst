.. code:: ipython3

    #Basic libraries
    import pandas as pd 
    import numpy as np 

.. code:: ipython3

    #Visualization libraries
    import matplotlib.pyplot as plt 
    from matplotlib import rcParams
    import seaborn as sns
    from textblob import TextBlob
    from plotly import tools
    import plotly.graph_objs as go
    from plotly.offline import iplot
    %matplotlib inline
    plt.rcParams['figure.figsize'] = [10, 5]
    import cufflinks as cf
    cf.go_offline()
    cf.set_config_file(offline=False, world_readable=True)



.. raw:: html

    <script type="text/javascript">
    window.PlotlyConfig = {MathJaxConfig: 'local'};
    if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}
    if (typeof require !== 'undefined') {
    require.undef("plotly");
    requirejs.config({
        paths: {
            'plotly': ['https://cdn.plot.ly/plotly-2.18.0.min']
        }
    });
    require(['plotly'], function(Plotly) {
        window._Plotly = Plotly;
    });
    }
    </script>
    


.. code:: ipython3

    #NLTK libraries
    import nltk
    import re
    import string
    from nltk.corpus import stopwords
    from wordcloud import WordCloud,STOPWORDS
    from nltk.stem.porter import PorterStemmer
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.feature_extraction.text import CountVectorizer

.. code:: ipython3

    # Machine Learning libraries
    import sklearn 
    from sklearn.model_selection import GridSearchCV
    from sklearn.linear_model import LogisticRegression
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.naive_bayes import MultinomialNB 
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.model_selection import train_test_split

.. code:: ipython3

    #Metrics libraries
    from sklearn import metrics
    from sklearn.metrics import classification_report
    from sklearn.model_selection import cross_val_score
    from sklearn.metrics import roc_auc_score
    from sklearn.metrics import roc_curve
    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import accuracy_score

.. code:: ipython3

    #Miscellanous libraries
    from collections import Counter
    
    #Ignore warnings
    import warnings
    warnings.filterwarnings('ignore')
    
    #Deep learning libraries
    from tensorflow.keras.layers import Embedding
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.preprocessing.text import one_hot
    from tensorflow.keras.layers import LSTM
    from tensorflow.keras.layers import Bidirectional
    from tensorflow.keras.layers import Dense
    from tensorflow.keras.layers import Dropout

.. code:: ipython3

    #NLTK libraries
    import nltk
    import re
    import string
    from nltk.corpus import stopwords
    from wordcloud import WordCloud,STOPWORDS
    from nltk.stem.porter import PorterStemmer
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.feature_extraction.text import CountVectorizer

.. code:: ipython3

    # Machine Learning libraries
    import sklearn 
    from sklearn.model_selection import GridSearchCV
    from sklearn.linear_model import LogisticRegression
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.naive_bayes import MultinomialNB 
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.model_selection import train_test_split

.. code:: ipython3

    #reading the fake and true datasets
    fake_news = pd.read_csv('Fake.csv')
    true_news = pd.read_csv('True.csv')
    
    # print shape of fake dataset with rows and columns and information 
    print ("The shape of the  data is (row, column):"+ str(fake_news.shape))
    print (fake_news.info())
    print("\n --------------------------------------- \n")
    
    # print shape of true dataset with rows and columns and information
    print ("The shape of the  data is (row, column):"+ str(true_news.shape))
    print (true_news.info())


.. parsed-literal::

    The shape of the  data is (row, column):(23481, 4)
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 23481 entries, 0 to 23480
    Data columns (total 4 columns):
     #   Column   Non-Null Count  Dtype 
    ---  ------   --------------  ----- 
     0   title    23481 non-null  object
     1   text     23481 non-null  object
     2   subject  23481 non-null  object
     3   date     23481 non-null  object
    dtypes: object(4)
    memory usage: 733.9+ KB
    None
    
     --------------------------------------- 
    
    The shape of the  data is (row, column):(21417, 4)
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 21417 entries, 0 to 21416
    Data columns (total 4 columns):
     #   Column   Non-Null Count  Dtype 
    ---  ------   --------------  ----- 
     0   title    21417 non-null  object
     1   text     21417 non-null  object
     2   subject  21417 non-null  object
     3   date     21417 non-null  object
    dtypes: object(4)
    memory usage: 669.4+ KB
    None
    

.. code:: ipython3

    #Target variable for fake news
    fake_news['output']=0
    
    #Target variable for true news
    true_news['output']=1

.. code:: ipython3

    #Concatenating and dropping for fake news
    fake_news['news']=fake_news['title']+fake_news['text']
    fake_news=fake_news.drop(['title', 'text'], axis=1)
    
    #Concatenating and dropping for true news
    true_news['news']=true_news['title']+true_news['text']
    true_news=true_news.drop(['title', 'text'], axis=1)
    
    #Rearranging the columns
    fake_news = fake_news[['subject', 'date', 'news','output']]
    true_news = true_news[['subject', 'date', 'news','output']]

.. code:: ipython3

    fake_news['date'].value_counts()




.. parsed-literal::

    May 10, 2017         46
    May 26, 2016         44
    May 6, 2016          44
    May 5, 2016          44
    May 11, 2016         43
                         ..
    December 9, 2017      1
    December 4, 2017      1
    November 19, 2017     1
    November 20, 2017     1
    Jul 19, 2015          1
    Name: date, Length: 1681, dtype: int64



.. code:: ipython3

    #Removing links and the headline from the date column
    fake_news=fake_news[~fake_news.date.str.contains("http")]
    fake_news=fake_news[~fake_news.date.str.contains("HOST")]
    
    '''You can also execute the below code to get the result 
    which allows only string which has the months and rest are filtered'''
    #fake_news=fake_news[fake_news.date.str.contains("Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec")]




.. parsed-literal::

    'You can also execute the below code to get the result \nwhich allows only string which has the months and rest are filtered'



.. code:: ipython3

    #Converting the date to datetime format
    fake_news['date'] = pd.to_datetime(fake_news['date'])
    true_news['date'] = pd.to_datetime(true_news['date'])

.. code:: ipython3

    frames = [fake_news, true_news]
    news_dataset = pd.concat(frames)
    news_dataset




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>subject</th>
          <th>date</th>
          <th>news</th>
          <th>output</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>News</td>
          <td>2017-12-31</td>
          <td>Donald Trump Sends Out Embarrassing New Year’...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>News</td>
          <td>2017-12-31</td>
          <td>Drunk Bragging Trump Staffer Started Russian ...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>News</td>
          <td>2017-12-30</td>
          <td>Sheriff David Clarke Becomes An Internet Joke...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>News</td>
          <td>2017-12-29</td>
          <td>Trump Is So Obsessed He Even Has Obama’s Name...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>News</td>
          <td>2017-12-25</td>
          <td>Pope Francis Just Called Out Donald Trump Dur...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>21412</th>
          <td>worldnews</td>
          <td>2017-08-22</td>
          <td>'Fully committed' NATO backs new U.S. approach...</td>
          <td>1</td>
        </tr>
        <tr>
          <th>21413</th>
          <td>worldnews</td>
          <td>2017-08-22</td>
          <td>LexisNexis withdrew two products from Chinese ...</td>
          <td>1</td>
        </tr>
        <tr>
          <th>21414</th>
          <td>worldnews</td>
          <td>2017-08-22</td>
          <td>Minsk cultural hub becomes haven from authorit...</td>
          <td>1</td>
        </tr>
        <tr>
          <th>21415</th>
          <td>worldnews</td>
          <td>2017-08-22</td>
          <td>Vatican upbeat on possibility of Pope Francis ...</td>
          <td>1</td>
        </tr>
        <tr>
          <th>21416</th>
          <td>worldnews</td>
          <td>2017-08-22</td>
          <td>Indonesia to buy $1.14 billion worth of Russia...</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    <p>44888 rows × 4 columns</p>
    </div>



.. code:: ipython3

    #Creating a copy 
    clean_news=news_dataset.copy()

.. code:: ipython3

    def review_cleaning(text):
        '''Make text lowercase, remove text in square brackets,remove links,remove punctuation
        and remove words containing numbers.'''
        text = str(text).lower()
        text = re.sub('\[.*?\]', '', text)
        text = re.sub('https?://\S+|www\.\S+', '', text)
        text = re.sub('<.*?>+', '', text)
        text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
        text = re.sub('\n', '', text)
        text = re.sub('\w*\d\w*', '', text)
        return text

.. code:: ipython3

    clean_news['news']=clean_news['news'].apply(lambda x:review_cleaning(x))
    clean_news.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>subject</th>
          <th>date</th>
          <th>news</th>
          <th>output</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>News</td>
          <td>2017-12-31</td>
          <td>donald trump sends out embarrassing new year’...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>News</td>
          <td>2017-12-31</td>
          <td>drunk bragging trump staffer started russian ...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>News</td>
          <td>2017-12-30</td>
          <td>sheriff david clarke becomes an internet joke...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>News</td>
          <td>2017-12-29</td>
          <td>trump is so obsessed he even has obama’s name...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>News</td>
          <td>2017-12-25</td>
          <td>pope francis just called out donald trump dur...</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    stop = stopwords.words('english')
    clean_news['news'] = clean_news['news'].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop)]))
    clean_news.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>subject</th>
          <th>date</th>
          <th>news</th>
          <th>output</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>News</td>
          <td>2017-12-31</td>
          <td>donald trump sends embarrassing new year’s eve...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>News</td>
          <td>2017-12-31</td>
          <td>drunk bragging trump staffer started russian c...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>News</td>
          <td>2017-12-30</td>
          <td>sheriff david clarke becomes internet joke thr...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>News</td>
          <td>2017-12-29</td>
          <td>trump obsessed even obama’s name coded website...</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>News</td>
          <td>2017-12-25</td>
          <td>pope francis called donald trump christmas spe...</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Plotting the frequency plot
    ax = sns.countplot(x="subject", data=clean_news,
                       facecolor=(0, 0, 0, 0),
                       linewidth=5,
                       edgecolor=sns.color_palette("dark", 3))
    
    #Setting labels and font size
    ax.set(xlabel='Type of news', ylabel='Number of news',title='Count of news type')
    ax.xaxis.get_label().set_fontsize(15)
    ax.yaxis.get_label().set_fontsize(14)



.. image:: output_19_0.png


.. code:: ipython3

    g = sns.catplot(x="subject", col="output",
                    data=clean_news, kind="count",
                    height=3, aspect=2)
    
    #Rotating the xlabels
    g.set_xticklabels(rotation=45)




.. parsed-literal::

    <seaborn.axisgrid.FacetGrid at 0x23bc6987910>




.. image:: output_20_1.png


.. code:: ipython3

    ax=sns.countplot(x="output", data=clean_news)
    
    #Setting labels and font size
    ax.set(xlabel='Output', ylabel='Count of fake/true',title='Count of fake and true news')
    ax.xaxis.get_label().set_fontsize(15)
    ax.yaxis.get_label().set_fontsize(15)



.. image:: output_21_0.png


.. code:: ipython3

    
    #Extracting the features from the news
    clean_news['polarity'] = clean_news['news'].map(lambda text: TextBlob(text).sentiment.polarity)
    clean_news['review_len'] = clean_news['news'].astype(str).apply(len)
    clean_news['word_count'] = clean_news['news'].apply(lambda x: len(str(x).split()))
    
    #Plotting the distribution of the extracted feature
    plt.figure(figsize = (20, 5))
    plt.style.use('seaborn-white')
    plt.subplot(131)
    sns.distplot(clean_news['polarity'])
    fig = plt.gcf()
    plt.subplot(132)
    sns.distplot(clean_news['review_len'])
    fig = plt.gcf()
    plt.subplot(133)
    sns.distplot(clean_news['word_count'])
    fig = plt.gcf()



.. image:: output_22_0.png


.. code:: ipython3

    #Function to get top n words
    def get_top_n_words(corpus, n=None):
        vec = CountVectorizer().fit(corpus)
        bag_of_words = vec.transform(corpus)
        sum_words = bag_of_words.sum(axis=0) 
        words_freq = [(word, sum_words[0, idx]) for word, idx in vec.vocabulary_.items()]
        words_freq =sorted(words_freq, key = lambda x: x[1], reverse=True)
        return words_freq[:n]
    
    #Calling function and return only top 20 words
    common_words = get_top_n_words(clean_news['news'], 20)
    
    #Printing the word and frequency
    for word, freq in common_words:
        print(word, freq)
    
    #Creating the dataframe of word and frequency
    df1 = pd.DataFrame(common_words, columns = ['news' , 'count'])
    
    #Group by words and plot the sum
    df1.groupby('news').sum()['count'].sort_values(ascending=False).iplot(
        kind='bar', yTitle='Count', linecolor='black', title='Top 20 words in news')


.. parsed-literal::

    trump 140400
    said 130258
    us 68081
    would 55422
    president 53189
    people 41718
    one 36146
    state 33190
    new 31799
    also 31209
    obama 29881
    clinton 29003
    house 28716
    government 27392
    donald 27376
    reuters 27348
    states 26331
    republican 25287
    could 24356
    white 23823
    


.. raw:: html

    <div>                            <div id="0698cd0d-dec8-471a-9a77-05127dcc3be1" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};
                        window.PLOTLYENV.BASE_URL='https://plot.ly';                                    if (document.getElementById("0698cd0d-dec8-471a-9a77-05127dcc3be1")) {                    Plotly.newPlot(                        "0698cd0d-dec8-471a-9a77-05127dcc3be1",                        [{"marker":{"color":"rgba(255, 153, 51, 0.6)","line":{"color":"rgba(255, 153, 51, 1.0)","width":1}},"name":"count","orientation":"v","text":"","x":["trump","said","us","would","president","people","one","state","new","also","obama","clinton","house","government","donald","reuters","states","republican","could","white"],"y":[140400,130258,68081,55422,53189,41718,36146,33190,31799,31209,29881,29003,28716,27392,27376,27348,26331,25287,24356,23823],"type":"bar"}],                        {"legend":{"bgcolor":"#F5F6F9","font":{"color":"#4D5663"}},"paper_bgcolor":"#F5F6F9","plot_bgcolor":"#F5F6F9","template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"font":{"color":"#4D5663"},"text":"Top 20 words in news"},"xaxis":{"gridcolor":"#E1E5ED","linecolor":"black","showgrid":true,"tickfont":{"color":"#4D5663"},"title":{"font":{"color":"#4D5663"},"text":""},"zerolinecolor":"#E1E5ED"},"yaxis":{"gridcolor":"#E1E5ED","linecolor":"black","showgrid":true,"tickfont":{"color":"#4D5663"},"title":{"font":{"color":"#4D5663"},"text":"Count"},"zerolinecolor":"#E1E5ED"}},                        {"showLink": true, "linkText": "Export to plot.ly", "plotlyServerURL": "https://plot.ly", "responsive": true}                    ).then(function(){
    
    var gd = document.getElementById('0698cd0d-dec8-471a-9a77-05127dcc3be1');
    var x = new MutationObserver(function (mutations, observer) {{
            var display = window.getComputedStyle(gd).display;
            if (!display || display === 'none') {{
                console.log([gd, 'removed!']);
                Plotly.purge(gd);
                observer.disconnect();
            }}
    }});
    
    // Listen for the removal of the full notebook cells
    var notebookContainer = gd.closest('#notebook-container');
    if (notebookContainer) {{
        x.observe(notebookContainer, {childList: true});
    }}
    
    // Listen for the clearing of the current output cell
    var outputEl = gd.closest('.output');
    if (outputEl) {{
        x.observe(outputEl, {childList: true});
    }}
    
                            })                };                });            </script>        </div>


.. code:: ipython3

    #Function to get top bigram words
    def get_top_n_bigram(corpus, n=None):
        vec = CountVectorizer(ngram_range=(2, 2)).fit(corpus)
        bag_of_words = vec.transform(corpus)
        sum_words = bag_of_words.sum(axis=0) 
        words_freq = [(word, sum_words[0, idx]) for word, idx in vec.vocabulary_.items()]
        words_freq =sorted(words_freq, key = lambda x: x[1], reverse=True)
        return words_freq[:n]
    
    #Calling function and return only top 20 words
    common_words = get_top_n_bigram(clean_news['news'], 20)
    
    #Printing the word and frequency
    for word, freq in common_words:
        print(word, freq)
        
    #Creating the dataframe of word and frequency
    df3 = pd.DataFrame(common_words, columns = ['news' , 'count'])
    
    #Group by words and plot the sum
    df3.groupby('news').sum()['count'].sort_values(ascending=False).iplot(
        kind='bar', yTitle='Count', linecolor='black', title='Top 20 bigrams in news')


.. parsed-literal::

    donald trump 25059
    united states 18394
    white house 15485
    hillary clinton 9502
    new york 8110
    north korea 7053
    president donald 6928
    image via 6188
    barack obama 5603
    trump said 4816
    prime minister 4753
    president trump 4646
    supreme court 4595
    last year 4560
    last week 4512
    said statement 4425
    fox news 4074
    president obama 4065
    islamic state 4014
    national security 3858
    


.. raw:: html

    <div>                            <div id="ae0b00f3-7ff7-4787-b375-47c919ddcf12" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};
                        window.PLOTLYENV.BASE_URL='https://plot.ly';                                    if (document.getElementById("ae0b00f3-7ff7-4787-b375-47c919ddcf12")) {                    Plotly.newPlot(                        "ae0b00f3-7ff7-4787-b375-47c919ddcf12",                        [{"marker":{"color":"rgba(255, 153, 51, 0.6)","line":{"color":"rgba(255, 153, 51, 1.0)","width":1}},"name":"count","orientation":"v","text":"","x":["donald trump","united states","white house","hillary clinton","new york","north korea","president donald","image via","barack obama","trump said","prime minister","president trump","supreme court","last year","last week","said statement","fox news","president obama","islamic state","national security"],"y":[25059,18394,15485,9502,8110,7053,6928,6188,5603,4816,4753,4646,4595,4560,4512,4425,4074,4065,4014,3858],"type":"bar"}],                        {"legend":{"bgcolor":"#F5F6F9","font":{"color":"#4D5663"}},"paper_bgcolor":"#F5F6F9","plot_bgcolor":"#F5F6F9","template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"font":{"color":"#4D5663"},"text":"Top 20 bigrams in news"},"xaxis":{"gridcolor":"#E1E5ED","linecolor":"black","showgrid":true,"tickfont":{"color":"#4D5663"},"title":{"font":{"color":"#4D5663"},"text":""},"zerolinecolor":"#E1E5ED"},"yaxis":{"gridcolor":"#E1E5ED","linecolor":"black","showgrid":true,"tickfont":{"color":"#4D5663"},"title":{"font":{"color":"#4D5663"},"text":"Count"},"zerolinecolor":"#E1E5ED"}},                        {"showLink": true, "linkText": "Export to plot.ly", "plotlyServerURL": "https://plot.ly", "responsive": true}                    ).then(function(){
    
    var gd = document.getElementById('ae0b00f3-7ff7-4787-b375-47c919ddcf12');
    var x = new MutationObserver(function (mutations, observer) {{
            var display = window.getComputedStyle(gd).display;
            if (!display || display === 'none') {{
                console.log([gd, 'removed!']);
                Plotly.purge(gd);
                observer.disconnect();
            }}
    }});
    
    // Listen for the removal of the full notebook cells
    var notebookContainer = gd.closest('#notebook-container');
    if (notebookContainer) {{
        x.observe(notebookContainer, {childList: true});
    }}
    
    // Listen for the clearing of the current output cell
    var outputEl = gd.closest('.output');
    if (outputEl) {{
        x.observe(outputEl, {childList: true});
    }}
    
                            })                };                });            </script>        </div>


.. code:: ipython3

    #Function to get top trigram words
    def get_top_n_trigram(corpus, n=None):
        vec = CountVectorizer(ngram_range=(3, 3), stop_words='english').fit(corpus)
        bag_of_words = vec.transform(corpus)
        sum_words = bag_of_words.sum(axis=0) 
        words_freq = [(word, sum_words[0, idx]) for word, idx in vec.vocabulary_.items()]
        words_freq =sorted(words_freq, key = lambda x: x[1], reverse=True)
        return words_freq[:n]
    
    #Calling function and return only top 20 words
    common_words = get_top_n_trigram(clean_news['news'], 20)
    
    #Printing word and their respective frequencies
    for word, freq in common_words:
        print(word, freq)
    
    #Creating a dataframe with words and count
    df6 = pd.DataFrame(common_words, columns = ['news' , 'count'])
    
    #Grouping the words and plotting their frequencies
    df6.groupby('news').sum()['count'].sort_values(ascending=False).iplot(
        kind='bar', yTitle='Count', linecolor='black', title='Top 20 trigrams in news')


.. parsed-literal::

    president donald trump 6808
    president barack obama 3735
    new york times 2034
    donald trump realdonaldtrump 1790
    reuters president donald 1476
    black lives matter 1436
    president united states 1096
    white house said 1050
    presidentelect donald trump 1043
    new york city 1006
    president vladimir putin 955
    news century wire 951
    national security adviser 898
    affordable care act 868
    director james comey 860
    speaker paul ryan 851
    fbi director james 778
    state rex tillerson 775
    secretary state rex 765
    russian president vladimir 745
    


.. raw:: html

    <div>                            <div id="edb36607-b64d-4d24-85ab-0a8d8bdb5b63" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};
                        window.PLOTLYENV.BASE_URL='https://plot.ly';                                    if (document.getElementById("edb36607-b64d-4d24-85ab-0a8d8bdb5b63")) {                    Plotly.newPlot(                        "edb36607-b64d-4d24-85ab-0a8d8bdb5b63",                        [{"marker":{"color":"rgba(255, 153, 51, 0.6)","line":{"color":"rgba(255, 153, 51, 1.0)","width":1}},"name":"count","orientation":"v","text":"","x":["president donald trump","president barack obama","new york times","donald trump realdonaldtrump","reuters president donald","black lives matter","president united states","white house said","presidentelect donald trump","new york city","president vladimir putin","news century wire","national security adviser","affordable care act","director james comey","speaker paul ryan","fbi director james","state rex tillerson","secretary state rex","russian president vladimir"],"y":[6808,3735,2034,1790,1476,1436,1096,1050,1043,1006,955,951,898,868,860,851,778,775,765,745],"type":"bar"}],                        {"legend":{"bgcolor":"#F5F6F9","font":{"color":"#4D5663"}},"paper_bgcolor":"#F5F6F9","plot_bgcolor":"#F5F6F9","template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"font":{"color":"#4D5663"},"text":"Top 20 trigrams in news"},"xaxis":{"gridcolor":"#E1E5ED","linecolor":"black","showgrid":true,"tickfont":{"color":"#4D5663"},"title":{"font":{"color":"#4D5663"},"text":""},"zerolinecolor":"#E1E5ED"},"yaxis":{"gridcolor":"#E1E5ED","linecolor":"black","showgrid":true,"tickfont":{"color":"#4D5663"},"title":{"font":{"color":"#4D5663"},"text":"Count"},"zerolinecolor":"#E1E5ED"}},                        {"showLink": true, "linkText": "Export to plot.ly", "plotlyServerURL": "https://plot.ly", "responsive": true}                    ).then(function(){
    
    var gd = document.getElementById('edb36607-b64d-4d24-85ab-0a8d8bdb5b63');
    var x = new MutationObserver(function (mutations, observer) {{
            var display = window.getComputedStyle(gd).display;
            if (!display || display === 'none') {{
                console.log([gd, 'removed!']);
                Plotly.purge(gd);
                observer.disconnect();
            }}
    }});
    
    // Listen for the removal of the full notebook cells
    var notebookContainer = gd.closest('#notebook-container');
    if (notebookContainer) {{
        x.observe(notebookContainer, {childList: true});
    }}
    
    // Listen for the clearing of the current output cell
    var outputEl = gd.closest('.output');
    if (outputEl) {{
        x.observe(outputEl, {childList: true});
    }}
    
                            })                };                });            </script>        </div>


.. code:: ipython3

    text = fake_news["news"]
    wordcloud = WordCloud(
        width = 3000,
        height = 2000,
        background_color = 'black',
        stopwords = STOPWORDS).generate(str(text))
    fig = plt.figure(
        figsize = (40, 30),
        facecolor = 'k',
        edgecolor = 'k')
    plt.imshow(wordcloud, interpolation = 'bilinear')
    plt.axis('off')
    plt.tight_layout(pad=0)
    plt.show()



.. image:: output_26_0.png


.. code:: ipython3

    text = true_news["news"]
    wordcloud = WordCloud(
        width = 3000,
        height = 2000,
        background_color = 'black',
        stopwords = STOPWORDS).generate(str(text))
    fig = plt.figure(
        figsize = (40, 30),
        facecolor = 'k',
        edgecolor = 'k')
    plt.imshow(wordcloud, interpolation = 'bilinear')
    plt.axis('off')
    plt.tight_layout(pad=0)
    plt.show()



.. image:: output_27_0.png


.. code:: ipython3

    #Creating the count of output based on date
    fake=fake_news.groupby(['date'])['output'].count()
    fake=pd.DataFrame(fake)
    
    true=true_news.groupby(['date'])['output'].count()
    true=pd.DataFrame(true)
    
    #Plotting the time series graph
    fig = go.Figure()
    fig.add_trace(go.Scatter(
             x=true.index,
             y=true['output'],
             name='True',
        line=dict(color='blue'),
        opacity=0.8))
    
    fig.add_trace(go.Scatter(
             x=fake.index,
             y=fake['output'],
             name='Fake',
        line=dict(color='red'),
        opacity=0.8))
    
    fig.update_xaxes(
        rangeslider_visible=True,
        rangeselector=dict(
            buttons=list([
                dict(count=1, label="1m", step="month", stepmode="backward"),
                dict(count=6, label="6m", step="month", stepmode="backward"),
                dict(count=1, label="YTD", step="year", stepmode="todate"),
                dict(count=1, label="1y", step="year", stepmode="backward"),
                dict(step="all")
            ])
        )
    )
            
        
    fig.update_layout(title_text='True and Fake News',plot_bgcolor='rgb(248, 248, 255)',yaxis_title='Value')
    
    fig.show()



.. raw:: html

    <div>                            <div id="ebba7e91-e5e5-40db-9c6e-ef82e1299a2e" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("ebba7e91-e5e5-40db-9c6e-ef82e1299a2e")) {                    Plotly.newPlot(                        "ebba7e91-e5e5-40db-9c6e-ef82e1299a2e",                        [{"line":{"color":"blue"},"name":"True","opacity":0.8,"x":["2016-01-13T00:00:00","2016-01-14T00:00:00","2016-01-15T00:00:00","2016-01-16T00:00:00","2016-01-17T00:00:00","2016-01-18T00:00:00","2016-01-19T00:00:00","2016-01-20T00:00:00","2016-01-21T00:00:00","2016-01-22T00:00:00","2016-01-23T00:00:00","2016-01-24T00:00:00","2016-01-25T00:00:00","2016-01-26T00:00:00","2016-01-27T00:00:00","2016-01-28T00:00:00","2016-01-29T00:00:00","2016-01-30T00:00:00","2016-01-31T00:00:00","2016-02-01T00:00:00","2016-02-02T00:00:00","2016-02-03T00:00:00","2016-02-04T00:00:00","2016-02-05T00:00:00","2016-02-06T00:00:00","2016-02-07T00:00:00","2016-02-08T00:00:00","2016-02-09T00:00:00","2016-02-10T00:00:00","2016-02-11T00:00:00","2016-02-12T00:00:00","2016-02-13T00:00:00","2016-02-14T00:00:00","2016-02-15T00:00:00","2016-02-16T00:00:00","2016-02-17T00:00:00","2016-02-18T00:00:00","2016-02-19T00:00:00","2016-02-20T00:00:00","2016-02-21T00:00:00","2016-02-22T00:00:00","2016-02-23T00:00:00","2016-02-24T00:00:00","2016-02-25T00:00:00","2016-02-26T00:00:00","2016-02-27T00:00:00","2016-02-28T00:00:00","2016-02-29T00:00:00","2016-03-01T00:00:00","2016-03-02T00:00:00","2016-03-03T00:00:00","2016-03-04T00:00:00","2016-03-05T00:00:00","2016-03-06T00:00:00","2016-03-07T00:00:00","2016-03-08T00:00:00","2016-03-09T00:00:00","2016-03-10T00:00:00","2016-03-11T00:00:00","2016-03-12T00:00:00","2016-03-13T00:00:00","2016-03-14T00:00:00","2016-03-15T00:00:00","2016-03-16T00:00:00","2016-03-17T00:00:00","2016-03-18T00:00:00","2016-03-19T00:00:00","2016-03-20T00:00:00","2016-03-21T00:00:00","2016-03-22T00:00:00","2016-03-23T00:00:00","2016-03-24T00:00:00","2016-03-25T00:00:00","2016-03-26T00:00:00","2016-03-27T00:00:00","2016-03-28T00:00:00","2016-03-29T00:00:00","2016-03-30T00:00:00","2016-03-31T00:00:00","2016-04-01T00:00:00","2016-04-02T00:00:00","2016-04-03T00:00:00","2016-04-04T00:00:00","2016-04-05T00:00:00","2016-04-06T00:00:00","2016-04-07T00:00:00","2016-04-08T00:00:00","2016-04-09T00:00:00","2016-04-10T00:00:00","2016-04-11T00:00:00","2016-04-12T00:00:00","2016-04-13T00:00:00","2016-04-14T00:00:00","2016-04-15T00:00:00","2016-04-16T00:00:00","2016-04-17T00:00:00","2016-04-18T00:00:00","2016-04-19T00:00:00","2016-04-20T00:00:00","2016-04-21T00:00:00","2016-04-22T00:00:00","2016-04-23T00:00:00","2016-04-24T00:00:00","2016-04-25T00:00:00","2016-04-26T00:00:00","2016-04-27T00:00:00","2016-04-28T00:00:00","2016-04-29T00:00:00","2016-04-30T00:00:00","2016-05-01T00:00:00","2016-05-02T00:00:00","2016-05-03T00:00:00","2016-05-04T00:00:00","2016-05-05T00:00:00","2016-05-06T00:00:00","2016-05-07T00:00:00","2016-05-08T00:00:00","2016-05-09T00:00:00","2016-05-10T00:00:00","2016-05-11T00:00:00","2016-05-12T00:00:00","2016-05-13T00:00:00","2016-05-14T00:00:00","2016-05-15T00:00:00","2016-05-16T00:00:00","2016-05-17T00:00:00","2016-05-18T00:00:00","2016-05-19T00:00:00","2016-05-20T00:00:00","2016-05-21T00:00:00","2016-05-22T00:00:00","2016-05-23T00:00:00","2016-05-24T00:00:00","2016-05-25T00:00:00","2016-05-26T00:00:00","2016-05-27T00:00:00","2016-05-28T00:00:00","2016-05-29T00:00:00","2016-05-30T00:00:00","2016-05-31T00:00:00","2016-06-01T00:00:00","2016-06-02T00:00:00","2016-06-03T00:00:00","2016-06-04T00:00:00","2016-06-05T00:00:00","2016-06-06T00:00:00","2016-06-07T00:00:00","2016-06-08T00:00:00","2016-06-09T00:00:00","2016-06-10T00:00:00","2016-06-11T00:00:00","2016-06-12T00:00:00","2016-06-13T00:00:00","2016-06-14T00:00:00","2016-06-15T00:00:00","2016-06-16T00:00:00","2016-06-17T00:00:00","2016-06-18T00:00:00","2016-06-19T00:00:00","2016-06-20T00:00:00","2016-06-21T00:00:00","2016-06-22T00:00:00","2016-06-23T00:00:00","2016-06-24T00:00:00","2016-06-25T00:00:00","2016-06-26T00:00:00","2016-06-27T00:00:00","2016-06-28T00:00:00","2016-06-29T00:00:00","2016-06-30T00:00:00","2016-07-01T00:00:00","2016-07-02T00:00:00","2016-07-03T00:00:00","2016-07-04T00:00:00","2016-07-05T00:00:00","2016-07-06T00:00:00","2016-07-07T00:00:00","2016-07-08T00:00:00","2016-07-09T00:00:00","2016-07-10T00:00:00","2016-07-11T00:00:00","2016-07-12T00:00:00","2016-07-13T00:00:00","2016-07-14T00:00:00","2016-07-15T00:00:00","2016-07-16T00:00:00","2016-07-17T00:00:00","2016-07-18T00:00:00","2016-07-19T00:00:00","2016-07-20T00:00:00","2016-07-21T00:00:00","2016-07-22T00:00:00","2016-07-23T00:00:00","2016-07-24T00:00:00","2016-07-25T00:00:00","2016-07-26T00:00:00","2016-07-27T00:00:00","2016-07-28T00:00:00","2016-07-29T00:00:00","2016-07-30T00:00:00","2016-07-31T00:00:00","2016-08-01T00:00:00","2016-08-02T00:00:00","2016-08-03T00:00:00","2016-08-04T00:00:00","2016-08-05T00:00:00","2016-08-06T00:00:00","2016-08-07T00:00:00","2016-08-08T00:00:00","2016-08-09T00:00:00","2016-08-10T00:00:00","2016-08-11T00:00:00","2016-08-12T00:00:00","2016-08-13T00:00:00","2016-08-14T00:00:00","2016-08-15T00:00:00","2016-08-16T00:00:00","2016-08-17T00:00:00","2016-08-18T00:00:00","2016-08-19T00:00:00","2016-08-21T00:00:00","2016-08-22T00:00:00","2016-08-23T00:00:00","2016-08-24T00:00:00","2016-08-25T00:00:00","2016-08-26T00:00:00","2016-08-27T00:00:00","2016-08-28T00:00:00","2016-08-29T00:00:00","2016-08-30T00:00:00","2016-08-31T00:00:00","2016-09-01T00:00:00","2016-09-02T00:00:00","2016-09-03T00:00:00","2016-09-04T00:00:00","2016-09-05T00:00:00","2016-09-06T00:00:00","2016-09-07T00:00:00","2016-09-08T00:00:00","2016-09-09T00:00:00","2016-09-10T00:00:00","2016-09-11T00:00:00","2016-09-12T00:00:00","2016-09-13T00:00:00","2016-09-14T00:00:00","2016-09-15T00:00:00","2016-09-16T00:00:00","2016-09-17T00:00:00","2016-09-18T00:00:00","2016-09-19T00:00:00","2016-09-20T00:00:00","2016-09-21T00:00:00","2016-09-22T00:00:00","2016-09-23T00:00:00","2016-09-24T00:00:00","2016-09-25T00:00:00","2016-09-26T00:00:00","2016-09-27T00:00:00","2016-09-28T00:00:00","2016-09-29T00:00:00","2016-09-30T00:00:00","2016-10-01T00:00:00","2016-10-02T00:00:00","2016-10-03T00:00:00","2016-10-04T00:00:00","2016-10-05T00:00:00","2016-10-06T00:00:00","2016-10-07T00:00:00","2016-10-08T00:00:00","2016-10-09T00:00:00","2016-10-10T00:00:00","2016-10-11T00:00:00","2016-10-12T00:00:00","2016-10-13T00:00:00","2016-10-14T00:00:00","2016-10-15T00:00:00","2016-10-16T00:00:00","2016-10-17T00:00:00","2016-10-18T00:00:00","2016-10-19T00:00:00","2016-10-20T00:00:00","2016-10-21T00:00:00","2016-10-22T00:00:00","2016-10-23T00:00:00","2016-10-24T00:00:00","2016-10-25T00:00:00","2016-10-26T00:00:00","2016-10-27T00:00:00","2016-10-28T00:00:00","2016-10-29T00:00:00","2016-10-30T00:00:00","2016-10-31T00:00:00","2016-11-01T00:00:00","2016-11-02T00:00:00","2016-11-03T00:00:00","2016-11-04T00:00:00","2016-11-05T00:00:00","2016-11-06T00:00:00","2016-11-07T00:00:00","2016-11-08T00:00:00","2016-11-09T00:00:00","2016-11-10T00:00:00","2016-11-11T00:00:00","2016-11-12T00:00:00","2016-11-13T00:00:00","2016-11-14T00:00:00","2016-11-15T00:00:00","2016-11-16T00:00:00","2016-11-17T00:00:00","2016-11-18T00:00:00","2016-11-19T00:00:00","2016-11-20T00:00:00","2016-11-21T00:00:00","2016-11-22T00:00:00","2016-11-23T00:00:00","2016-11-24T00:00:00","2016-11-25T00:00:00","2016-11-26T00:00:00","2016-11-27T00:00:00","2016-11-28T00:00:00","2016-11-29T00:00:00","2016-11-30T00:00:00","2016-12-01T00:00:00","2016-12-02T00:00:00","2016-12-03T00:00:00","2016-12-04T00:00:00","2016-12-05T00:00:00","2016-12-06T00:00:00","2016-12-07T00:00:00","2016-12-08T00:00:00","2016-12-09T00:00:00","2016-12-10T00:00:00","2016-12-11T00:00:00","2016-12-12T00:00:00","2016-12-13T00:00:00","2016-12-14T00:00:00","2016-12-15T00:00:00","2016-12-16T00:00:00","2016-12-17T00:00:00","2016-12-18T00:00:00","2016-12-19T00:00:00","2016-12-20T00:00:00","2016-12-21T00:00:00","2016-12-22T00:00:00","2016-12-23T00:00:00","2016-12-24T00:00:00","2016-12-25T00:00:00","2016-12-26T00:00:00","2016-12-27T00:00:00","2016-12-28T00:00:00","2016-12-29T00:00:00","2016-12-30T00:00:00","2017-01-01T00:00:00","2017-01-02T00:00:00","2017-01-03T00:00:00","2017-01-04T00:00:00","2017-01-05T00:00:00","2017-01-06T00:00:00","2017-01-07T00:00:00","2017-01-08T00:00:00","2017-01-09T00:00:00","2017-01-10T00:00:00","2017-01-11T00:00:00","2017-01-12T00:00:00","2017-01-13T00:00:00","2017-01-14T00:00:00","2017-01-15T00:00:00","2017-01-16T00:00:00","2017-01-17T00:00:00","2017-01-18T00:00:00","2017-01-19T00:00:00","2017-01-20T00:00:00","2017-01-21T00:00:00","2017-01-22T00:00:00","2017-01-23T00:00:00","2017-01-24T00:00:00","2017-01-25T00:00:00","2017-01-26T00:00:00","2017-01-27T00:00:00","2017-01-28T00:00:00","2017-01-29T00:00:00","2017-01-30T00:00:00","2017-01-31T00:00:00","2017-02-01T00:00:00","2017-02-02T00:00:00","2017-02-03T00:00:00","2017-02-04T00:00:00","2017-02-05T00:00:00","2017-02-06T00:00:00","2017-02-07T00:00:00","2017-02-08T00:00:00","2017-02-09T00:00:00","2017-02-10T00:00:00","2017-02-11T00:00:00","2017-02-12T00:00:00","2017-02-13T00:00:00","2017-02-14T00:00:00","2017-02-15T00:00:00","2017-02-16T00:00:00","2017-02-17T00:00:00","2017-02-18T00:00:00","2017-02-19T00:00:00","2017-02-20T00:00:00","2017-02-21T00:00:00","2017-02-22T00:00:00","2017-02-23T00:00:00","2017-02-24T00:00:00","2017-02-25T00:00:00","2017-02-26T00:00:00","2017-02-27T00:00:00","2017-02-28T00:00:00","2017-03-01T00:00:00","2017-03-02T00:00:00","2017-03-03T00:00:00","2017-03-04T00:00:00","2017-03-05T00:00:00","2017-03-06T00:00:00","2017-03-07T00:00:00","2017-03-08T00:00:00","2017-03-09T00:00:00","2017-03-10T00:00:00","2017-03-11T00:00:00","2017-03-12T00:00:00","2017-03-13T00:00:00","2017-03-14T00:00:00","2017-03-15T00:00:00","2017-03-16T00:00:00","2017-03-17T00:00:00","2017-03-18T00:00:00","2017-03-19T00:00:00","2017-03-20T00:00:00","2017-03-21T00:00:00","2017-03-22T00:00:00","2017-03-23T00:00:00","2017-03-24T00:00:00","2017-03-25T00:00:00","2017-03-26T00:00:00","2017-03-27T00:00:00","2017-03-28T00:00:00","2017-03-29T00:00:00","2017-03-30T00:00:00","2017-03-31T00:00:00","2017-04-01T00:00:00","2017-04-02T00:00:00","2017-04-03T00:00:00","2017-04-04T00:00:00","2017-04-05T00:00:00","2017-04-06T00:00:00","2017-04-07T00:00:00","2017-04-08T00:00:00","2017-04-09T00:00:00","2017-04-10T00:00:00","2017-04-11T00:00:00","2017-04-12T00:00:00","2017-04-13T00:00:00","2017-04-14T00:00:00","2017-04-15T00:00:00","2017-04-16T00:00:00","2017-04-17T00:00:00","2017-04-18T00:00:00","2017-04-19T00:00:00","2017-04-20T00:00:00","2017-04-21T00:00:00","2017-04-22T00:00:00","2017-04-23T00:00:00","2017-04-24T00:00:00","2017-04-25T00:00:00","2017-04-26T00:00:00","2017-04-27T00:00:00","2017-04-28T00:00:00","2017-04-29T00:00:00","2017-04-30T00:00:00","2017-05-01T00:00:00","2017-05-02T00:00:00","2017-05-03T00:00:00","2017-05-04T00:00:00","2017-05-05T00:00:00","2017-05-06T00:00:00","2017-05-07T00:00:00","2017-05-08T00:00:00","2017-05-09T00:00:00","2017-05-10T00:00:00","2017-05-11T00:00:00","2017-05-12T00:00:00","2017-05-14T00:00:00","2017-05-15T00:00:00","2017-05-16T00:00:00","2017-05-17T00:00:00","2017-05-18T00:00:00","2017-05-19T00:00:00","2017-05-20T00:00:00","2017-05-21T00:00:00","2017-05-22T00:00:00","2017-05-23T00:00:00","2017-05-24T00:00:00","2017-05-25T00:00:00","2017-05-26T00:00:00","2017-05-27T00:00:00","2017-05-28T00:00:00","2017-05-29T00:00:00","2017-05-30T00:00:00","2017-05-31T00:00:00","2017-06-01T00:00:00","2017-06-02T00:00:00","2017-06-03T00:00:00","2017-06-04T00:00:00","2017-06-05T00:00:00","2017-06-06T00:00:00","2017-06-07T00:00:00","2017-06-08T00:00:00","2017-06-09T00:00:00","2017-06-10T00:00:00","2017-06-11T00:00:00","2017-06-12T00:00:00","2017-06-13T00:00:00","2017-06-14T00:00:00","2017-06-15T00:00:00","2017-06-16T00:00:00","2017-06-17T00:00:00","2017-06-18T00:00:00","2017-06-19T00:00:00","2017-06-20T00:00:00","2017-06-21T00:00:00","2017-06-22T00:00:00","2017-06-23T00:00:00","2017-06-24T00:00:00","2017-06-25T00:00:00","2017-06-26T00:00:00","2017-06-27T00:00:00","2017-06-28T00:00:00","2017-06-29T00:00:00","2017-06-30T00:00:00","2017-07-01T00:00:00","2017-07-02T00:00:00","2017-07-03T00:00:00","2017-07-04T00:00:00","2017-07-05T00:00:00","2017-07-06T00:00:00","2017-07-07T00:00:00","2017-07-08T00:00:00","2017-07-09T00:00:00","2017-07-10T00:00:00","2017-07-11T00:00:00","2017-07-12T00:00:00","2017-07-13T00:00:00","2017-07-14T00:00:00","2017-07-15T00:00:00","2017-07-16T00:00:00","2017-07-17T00:00:00","2017-07-18T00:00:00","2017-07-19T00:00:00","2017-07-20T00:00:00","2017-07-21T00:00:00","2017-07-22T00:00:00","2017-07-23T00:00:00","2017-07-24T00:00:00","2017-07-25T00:00:00","2017-07-26T00:00:00","2017-07-27T00:00:00","2017-07-28T00:00:00","2017-07-29T00:00:00","2017-07-30T00:00:00","2017-07-31T00:00:00","2017-08-01T00:00:00","2017-08-02T00:00:00","2017-08-03T00:00:00","2017-08-04T00:00:00","2017-08-05T00:00:00","2017-08-06T00:00:00","2017-08-07T00:00:00","2017-08-08T00:00:00","2017-08-09T00:00:00","2017-08-10T00:00:00","2017-08-11T00:00:00","2017-08-12T00:00:00","2017-08-13T00:00:00","2017-08-14T00:00:00","2017-08-15T00:00:00","2017-08-16T00:00:00","2017-08-17T00:00:00","2017-08-18T00:00:00","2017-08-19T00:00:00","2017-08-20T00:00:00","2017-08-21T00:00:00","2017-08-22T00:00:00","2017-08-23T00:00:00","2017-08-24T00:00:00","2017-08-25T00:00:00","2017-08-26T00:00:00","2017-08-27T00:00:00","2017-08-28T00:00:00","2017-08-29T00:00:00","2017-08-30T00:00:00","2017-08-31T00:00:00","2017-09-01T00:00:00","2017-09-02T00:00:00","2017-09-03T00:00:00","2017-09-04T00:00:00","2017-09-05T00:00:00","2017-09-06T00:00:00","2017-09-07T00:00:00","2017-09-08T00:00:00","2017-09-09T00:00:00","2017-09-10T00:00:00","2017-09-11T00:00:00","2017-09-12T00:00:00","2017-09-13T00:00:00","2017-09-14T00:00:00","2017-09-15T00:00:00","2017-09-16T00:00:00","2017-09-17T00:00:00","2017-09-18T00:00:00","2017-09-19T00:00:00","2017-09-20T00:00:00","2017-09-21T00:00:00","2017-09-22T00:00:00","2017-09-23T00:00:00","2017-09-24T00:00:00","2017-09-25T00:00:00","2017-09-26T00:00:00","2017-09-27T00:00:00","2017-09-28T00:00:00","2017-09-29T00:00:00","2017-09-30T00:00:00","2017-10-01T00:00:00","2017-10-02T00:00:00","2017-10-03T00:00:00","2017-10-04T00:00:00","2017-10-05T00:00:00","2017-10-06T00:00:00","2017-10-07T00:00:00","2017-10-08T00:00:00","2017-10-09T00:00:00","2017-10-10T00:00:00","2017-10-11T00:00:00","2017-10-12T00:00:00","2017-10-13T00:00:00","2017-10-14T00:00:00","2017-10-15T00:00:00","2017-10-16T00:00:00","2017-10-17T00:00:00","2017-10-18T00:00:00","2017-10-19T00:00:00","2017-10-20T00:00:00","2017-10-21T00:00:00","2017-10-22T00:00:00","2017-10-23T00:00:00","2017-10-24T00:00:00","2017-10-25T00:00:00","2017-10-26T00:00:00","2017-10-27T00:00:00","2017-10-28T00:00:00","2017-10-29T00:00:00","2017-10-30T00:00:00","2017-10-31T00:00:00","2017-11-01T00:00:00","2017-11-02T00:00:00","2017-11-03T00:00:00","2017-11-04T00:00:00","2017-11-05T00:00:00","2017-11-06T00:00:00","2017-11-07T00:00:00","2017-11-08T00:00:00","2017-11-09T00:00:00","2017-11-10T00:00:00","2017-11-11T00:00:00","2017-11-12T00:00:00","2017-11-13T00:00:00","2017-11-14T00:00:00","2017-11-15T00:00:00","2017-11-16T00:00:00","2017-11-17T00:00:00","2017-11-18T00:00:00","2017-11-19T00:00:00","2017-11-20T00:00:00","2017-11-21T00:00:00","2017-11-22T00:00:00","2017-11-23T00:00:00","2017-11-24T00:00:00","2017-11-25T00:00:00","2017-11-26T00:00:00","2017-11-27T00:00:00","2017-11-28T00:00:00","2017-11-29T00:00:00","2017-11-30T00:00:00","2017-12-01T00:00:00","2017-12-02T00:00:00","2017-12-03T00:00:00","2017-12-04T00:00:00","2017-12-05T00:00:00","2017-12-06T00:00:00","2017-12-07T00:00:00","2017-12-08T00:00:00","2017-12-09T00:00:00","2017-12-10T00:00:00","2017-12-11T00:00:00","2017-12-12T00:00:00","2017-12-13T00:00:00","2017-12-14T00:00:00","2017-12-15T00:00:00","2017-12-16T00:00:00","2017-12-17T00:00:00","2017-12-18T00:00:00","2017-12-19T00:00:00","2017-12-20T00:00:00","2017-12-21T00:00:00","2017-12-22T00:00:00","2017-12-23T00:00:00","2017-12-24T00:00:00","2017-12-25T00:00:00","2017-12-26T00:00:00","2017-12-27T00:00:00","2017-12-28T00:00:00","2017-12-29T00:00:00","2017-12-30T00:00:00","2017-12-31T00:00:00"],"y":[30,15,23,5,3,6,13,19,20,15,3,1,9,16,19,19,19,7,4,11,16,19,24,15,5,4,14,21,25,18,13,4,12,7,15,11,19,22,5,8,20,24,24,23,22,7,8,16,22,21,33,26,6,3,19,21,24,25,20,7,2,10,18,38,24,15,3,9,23,23,20,14,6,2,4,7,15,20,10,14,2,5,14,17,13,22,10,9,3,13,16,21,18,21,3,5,16,22,17,15,9,3,7,12,14,26,24,9,3,3,9,9,23,24,16,3,2,14,13,17,36,14,1,4,16,24,17,21,11,2,1,13,18,26,18,13,1,4,1,20,16,17,11,6,4,11,19,21,26,15,3,16,18,26,12,16,9,4,5,14,21,20,16,25,4,4,13,23,12,12,16,3,3,2,18,20,13,13,8,3,13,11,18,18,13,5,7,12,13,9,20,16,5,4,13,14,9,12,16,2,9,6,15,10,12,8,1,3,6,11,8,15,7,2,3,5,15,8,8,10,1,4,12,11,16,11,2,3,18,14,20,13,14,1,3,8,16,16,16,8,7,1,17,21,22,12,19,2,6,7,17,12,17,12,4,5,12,22,19,16,6,2,7,10,9,9,8,12,9,4,15,17,15,15,15,6,8,11,18,5,15,11,5,5,8,17,14,18,24,5,3,16,7,14,17,25,9,14,21,27,115,36,24,7,8,18,29,27,31,27,9,16,10,32,22,6,12,10,3,15,21,25,16,21,12,12,28,22,27,18,34,9,9,34,20,25,21,22,4,6,10,9,14,11,14,3,1,2,4,8,7,2,3,7,16,19,17,24,3,8,17,24,33,34,30,6,9,18,27,40,34,36,5,9,47,40,33,40,47,17,34,45,28,51,49,47,16,13,12,28,27,35,30,6,6,11,30,32,30,19,8,14,7,18,8,15,26,7,5,23,18,27,39,17,8,2,21,29,27,21,13,4,6,26,17,30,41,30,7,8,26,21,39,31,39,6,9,22,33,19,34,32,2,9,22,31,24,31,73,5,4,15,15,31,25,5,3,2,11,26,25,23,24,5,10,14,15,35,25,25,2,6,24,22,14,22,11,3,2,10,14,30,26,14,3,13,22,28,34,22,2,9,29,36,21,27,11,8,2,2,14,30,36,36,6,5,15,26,38,24,28,11,4,13,30,25,21,24,3,4,11,23,22,19,17,1,7,22,25,17,26,17,3,4,9,5,6,9,10,14,8,26,21,27,27,23,5,3,17,26,25,23,18,10,6,26,44,44,36,34,4,4,23,28,23,26,17,6,7,10,12,9,18,23,6,4,12,19,30,21,17,7,3,12,39,37,42,50,12,12,34,29,39,53,63,36,40,89,123,151,149,119,52,70,104,143,123,131,141,39,50,122,117,115,153,146,72,71,116,136,116,126,115,46,68,92,117,115,99,116,47,58,101,119,125,137,155,44,65,141,118,142,145,121,43,42,108,139,136,142,117,39,47,113,121,127,128,105,51,66,114,119,143,158,118,40,72,109,116,122,122,124,38,41,102,129,120,95,124,35,41,116,125,134,162,122,40,53,112,131,166,140,134,40,44,97,93,126,133,114,46,54,109,124,182,151,81,42,31,40,51,63,5,6,1,2],"type":"scatter"},{"line":{"color":"red"},"name":"Fake","opacity":0.8,"x":["2015-03-31T00:00:00","2015-04-01T00:00:00","2015-04-02T00:00:00","2015-04-04T00:00:00","2015-04-05T00:00:00","2015-04-06T00:00:00","2015-04-07T00:00:00","2015-04-08T00:00:00","2015-04-09T00:00:00","2015-04-10T00:00:00","2015-04-11T00:00:00","2015-04-12T00:00:00","2015-04-13T00:00:00","2015-04-14T00:00:00","2015-04-15T00:00:00","2015-04-16T00:00:00","2015-04-17T00:00:00","2015-04-18T00:00:00","2015-04-19T00:00:00","2015-04-20T00:00:00","2015-04-21T00:00:00","2015-04-22T00:00:00","2015-04-23T00:00:00","2015-04-24T00:00:00","2015-04-25T00:00:00","2015-04-26T00:00:00","2015-04-27T00:00:00","2015-04-28T00:00:00","2015-04-29T00:00:00","2015-04-30T00:00:00","2015-05-01T00:00:00","2015-05-02T00:00:00","2015-05-04T00:00:00","2015-05-05T00:00:00","2015-05-06T00:00:00","2015-05-07T00:00:00","2015-05-08T00:00:00","2015-05-09T00:00:00","2015-05-10T00:00:00","2015-05-11T00:00:00","2015-05-12T00:00:00","2015-05-13T00:00:00","2015-05-14T00:00:00","2015-05-15T00:00:00","2015-05-16T00:00:00","2015-05-17T00:00:00","2015-05-18T00:00:00","2015-05-19T00:00:00","2015-05-20T00:00:00","2015-05-21T00:00:00","2015-05-22T00:00:00","2015-05-23T00:00:00","2015-05-24T00:00:00","2015-05-25T00:00:00","2015-05-26T00:00:00","2015-05-27T00:00:00","2015-05-28T00:00:00","2015-05-29T00:00:00","2015-05-30T00:00:00","2015-05-31T00:00:00","2015-06-01T00:00:00","2015-06-02T00:00:00","2015-06-03T00:00:00","2015-06-04T00:00:00","2015-06-05T00:00:00","2015-06-07T00:00:00","2015-06-08T00:00:00","2015-06-09T00:00:00","2015-06-10T00:00:00","2015-06-11T00:00:00","2015-06-12T00:00:00","2015-06-13T00:00:00","2015-06-14T00:00:00","2015-06-15T00:00:00","2015-06-16T00:00:00","2015-06-17T00:00:00","2015-06-18T00:00:00","2015-06-19T00:00:00","2015-06-20T00:00:00","2015-06-21T00:00:00","2015-06-22T00:00:00","2015-06-23T00:00:00","2015-06-24T00:00:00","2015-06-25T00:00:00","2015-06-26T00:00:00","2015-06-27T00:00:00","2015-06-28T00:00:00","2015-06-29T00:00:00","2015-06-30T00:00:00","2015-07-01T00:00:00","2015-07-02T00:00:00","2015-07-03T00:00:00","2015-07-04T00:00:00","2015-07-05T00:00:00","2015-07-06T00:00:00","2015-07-07T00:00:00","2015-07-08T00:00:00","2015-07-09T00:00:00","2015-07-10T00:00:00","2015-07-11T00:00:00","2015-07-12T00:00:00","2015-07-13T00:00:00","2015-07-14T00:00:00","2015-07-15T00:00:00","2015-07-16T00:00:00","2015-07-17T00:00:00","2015-07-18T00:00:00","2015-07-19T00:00:00","2015-07-20T00:00:00","2015-07-21T00:00:00","2015-07-22T00:00:00","2015-07-23T00:00:00","2015-07-24T00:00:00","2015-07-25T00:00:00","2015-07-26T00:00:00","2015-07-27T00:00:00","2015-07-28T00:00:00","2015-07-29T00:00:00","2015-07-30T00:00:00","2015-07-31T00:00:00","2015-08-01T00:00:00","2015-08-02T00:00:00","2015-08-03T00:00:00","2015-08-04T00:00:00","2015-08-05T00:00:00","2015-08-06T00:00:00","2015-08-07T00:00:00","2015-08-08T00:00:00","2015-08-09T00:00:00","2015-08-10T00:00:00","2015-08-11T00:00:00","2015-08-12T00:00:00","2015-08-13T00:00:00","2015-08-14T00:00:00","2015-08-15T00:00:00","2015-08-16T00:00:00","2015-08-17T00:00:00","2015-08-18T00:00:00","2015-08-19T00:00:00","2015-08-20T00:00:00","2015-08-21T00:00:00","2015-08-22T00:00:00","2015-08-23T00:00:00","2015-08-24T00:00:00","2015-08-25T00:00:00","2015-08-26T00:00:00","2015-08-27T00:00:00","2015-08-28T00:00:00","2015-08-29T00:00:00","2015-08-30T00:00:00","2015-08-31T00:00:00","2015-09-01T00:00:00","2015-09-02T00:00:00","2015-09-03T00:00:00","2015-09-04T00:00:00","2015-09-05T00:00:00","2015-09-06T00:00:00","2015-09-07T00:00:00","2015-09-08T00:00:00","2015-09-09T00:00:00","2015-09-10T00:00:00","2015-09-11T00:00:00","2015-09-12T00:00:00","2015-09-13T00:00:00","2015-09-14T00:00:00","2015-09-15T00:00:00","2015-09-16T00:00:00","2015-09-17T00:00:00","2015-09-18T00:00:00","2015-09-19T00:00:00","2015-09-20T00:00:00","2015-09-21T00:00:00","2015-09-22T00:00:00","2015-09-23T00:00:00","2015-09-24T00:00:00","2015-09-25T00:00:00","2015-09-26T00:00:00","2015-09-27T00:00:00","2015-09-28T00:00:00","2015-09-29T00:00:00","2015-09-30T00:00:00","2015-10-01T00:00:00","2015-10-02T00:00:00","2015-10-03T00:00:00","2015-10-04T00:00:00","2015-10-05T00:00:00","2015-10-06T00:00:00","2015-10-07T00:00:00","2015-10-08T00:00:00","2015-10-09T00:00:00","2015-10-10T00:00:00","2015-10-11T00:00:00","2015-10-12T00:00:00","2015-10-13T00:00:00","2015-10-14T00:00:00","2015-10-15T00:00:00","2015-10-16T00:00:00","2015-10-17T00:00:00","2015-10-18T00:00:00","2015-10-19T00:00:00","2015-10-20T00:00:00","2015-10-21T00:00:00","2015-10-22T00:00:00","2015-10-23T00:00:00","2015-10-24T00:00:00","2015-10-25T00:00:00","2015-10-26T00:00:00","2015-10-27T00:00:00","2015-10-28T00:00:00","2015-10-29T00:00:00","2015-10-30T00:00:00","2015-10-31T00:00:00","2015-11-01T00:00:00","2015-11-02T00:00:00","2015-11-03T00:00:00","2015-11-04T00:00:00","2015-11-05T00:00:00","2015-11-06T00:00:00","2015-11-07T00:00:00","2015-11-08T00:00:00","2015-11-09T00:00:00","2015-11-10T00:00:00","2015-11-11T00:00:00","2015-11-12T00:00:00","2015-11-13T00:00:00","2015-11-14T00:00:00","2015-11-15T00:00:00","2015-11-16T00:00:00","2015-11-17T00:00:00","2015-11-18T00:00:00","2015-11-19T00:00:00","2015-11-20T00:00:00","2015-11-21T00:00:00","2015-11-22T00:00:00","2015-11-23T00:00:00","2015-11-24T00:00:00","2015-11-25T00:00:00","2015-11-26T00:00:00","2015-11-27T00:00:00","2015-11-28T00:00:00","2015-11-29T00:00:00","2015-11-30T00:00:00","2015-12-01T00:00:00","2015-12-02T00:00:00","2015-12-03T00:00:00","2015-12-04T00:00:00","2015-12-05T00:00:00","2015-12-06T00:00:00","2015-12-07T00:00:00","2015-12-08T00:00:00","2015-12-09T00:00:00","2015-12-10T00:00:00","2015-12-11T00:00:00","2015-12-12T00:00:00","2015-12-13T00:00:00","2015-12-14T00:00:00","2015-12-15T00:00:00","2015-12-16T00:00:00","2015-12-17T00:00:00","2015-12-18T00:00:00","2015-12-19T00:00:00","2015-12-20T00:00:00","2015-12-21T00:00:00","2015-12-22T00:00:00","2015-12-23T00:00:00","2015-12-24T00:00:00","2015-12-25T00:00:00","2015-12-26T00:00:00","2015-12-27T00:00:00","2015-12-28T00:00:00","2015-12-29T00:00:00","2015-12-30T00:00:00","2015-12-31T00:00:00","2016-01-01T00:00:00","2016-01-02T00:00:00","2016-01-03T00:00:00","2016-01-04T00:00:00","2016-01-05T00:00:00","2016-01-06T00:00:00","2016-01-07T00:00:00","2016-01-08T00:00:00","2016-01-09T00:00:00","2016-01-10T00:00:00","2016-01-11T00:00:00","2016-01-12T00:00:00","2016-01-13T00:00:00","2016-01-14T00:00:00","2016-01-15T00:00:00","2016-01-16T00:00:00","2016-01-17T00:00:00","2016-01-18T00:00:00","2016-01-19T00:00:00","2016-01-20T00:00:00","2016-01-21T00:00:00","2016-01-22T00:00:00","2016-01-23T00:00:00","2016-01-24T00:00:00","2016-01-25T00:00:00","2016-01-26T00:00:00","2016-01-27T00:00:00","2016-01-28T00:00:00","2016-01-29T00:00:00","2016-01-30T00:00:00","2016-01-31T00:00:00","2016-02-01T00:00:00","2016-02-02T00:00:00","2016-02-03T00:00:00","2016-02-04T00:00:00","2016-02-05T00:00:00","2016-02-06T00:00:00","2016-02-07T00:00:00","2016-02-08T00:00:00","2016-02-09T00:00:00","2016-02-10T00:00:00","2016-02-11T00:00:00","2016-02-12T00:00:00","2016-02-13T00:00:00","2016-02-14T00:00:00","2016-02-15T00:00:00","2016-02-16T00:00:00","2016-02-17T00:00:00","2016-02-18T00:00:00","2016-02-19T00:00:00","2016-02-20T00:00:00","2016-02-21T00:00:00","2016-02-22T00:00:00","2016-02-23T00:00:00","2016-02-24T00:00:00","2016-02-25T00:00:00","2016-02-26T00:00:00","2016-02-27T00:00:00","2016-02-28T00:00:00","2016-02-29T00:00:00","2016-03-01T00:00:00","2016-03-02T00:00:00","2016-03-03T00:00:00","2016-03-04T00:00:00","2016-03-05T00:00:00","2016-03-06T00:00:00","2016-03-07T00:00:00","2016-03-08T00:00:00","2016-03-09T00:00:00","2016-03-10T00:00:00","2016-03-11T00:00:00","2016-03-12T00:00:00","2016-03-13T00:00:00","2016-03-14T00:00:00","2016-03-15T00:00:00","2016-03-16T00:00:00","2016-03-17T00:00:00","2016-03-18T00:00:00","2016-03-19T00:00:00","2016-03-20T00:00:00","2016-03-21T00:00:00","2016-03-22T00:00:00","2016-03-23T00:00:00","2016-03-24T00:00:00","2016-03-25T00:00:00","2016-03-26T00:00:00","2016-03-27T00:00:00","2016-03-28T00:00:00","2016-03-29T00:00:00","2016-03-30T00:00:00","2016-03-31T00:00:00","2016-04-01T00:00:00","2016-04-02T00:00:00","2016-04-03T00:00:00","2016-04-04T00:00:00","2016-04-05T00:00:00","2016-04-06T00:00:00","2016-04-07T00:00:00","2016-04-08T00:00:00","2016-04-09T00:00:00","2016-04-10T00:00:00","2016-04-11T00:00:00","2016-04-12T00:00:00","2016-04-13T00:00:00","2016-04-14T00:00:00","2016-04-15T00:00:00","2016-04-16T00:00:00","2016-04-17T00:00:00","2016-04-18T00:00:00","2016-04-19T00:00:00","2016-04-20T00:00:00","2016-04-21T00:00:00","2016-04-22T00:00:00","2016-04-23T00:00:00","2016-04-24T00:00:00","2016-04-25T00:00:00","2016-04-26T00:00:00","2016-04-27T00:00:00","2016-04-28T00:00:00","2016-04-29T00:00:00","2016-04-30T00:00:00","2016-05-01T00:00:00","2016-05-02T00:00:00","2016-05-03T00:00:00","2016-05-04T00:00:00","2016-05-05T00:00:00","2016-05-06T00:00:00","2016-05-07T00:00:00","2016-05-08T00:00:00","2016-05-09T00:00:00","2016-05-10T00:00:00","2016-05-11T00:00:00","2016-05-12T00:00:00","2016-05-13T00:00:00","2016-05-14T00:00:00","2016-05-15T00:00:00","2016-05-16T00:00:00","2016-05-17T00:00:00","2016-05-18T00:00:00","2016-05-19T00:00:00","2016-05-20T00:00:00","2016-05-21T00:00:00","2016-05-22T00:00:00","2016-05-23T00:00:00","2016-05-24T00:00:00","2016-05-25T00:00:00","2016-05-26T00:00:00","2016-05-27T00:00:00","2016-05-28T00:00:00","2016-05-29T00:00:00","2016-05-30T00:00:00","2016-05-31T00:00:00","2016-06-01T00:00:00","2016-06-02T00:00:00","2016-06-03T00:00:00","2016-06-04T00:00:00","2016-06-05T00:00:00","2016-06-06T00:00:00","2016-06-07T00:00:00","2016-06-08T00:00:00","2016-06-09T00:00:00","2016-06-10T00:00:00","2016-06-11T00:00:00","2016-06-12T00:00:00","2016-06-13T00:00:00","2016-06-14T00:00:00","2016-06-15T00:00:00","2016-06-16T00:00:00","2016-06-17T00:00:00","2016-06-18T00:00:00","2016-06-19T00:00:00","2016-06-20T00:00:00","2016-06-21T00:00:00","2016-06-22T00:00:00","2016-06-23T00:00:00","2016-06-24T00:00:00","2016-06-25T00:00:00","2016-06-26T00:00:00","2016-06-27T00:00:00","2016-06-28T00:00:00","2016-06-29T00:00:00","2016-06-30T00:00:00","2016-07-01T00:00:00","2016-07-02T00:00:00","2016-07-03T00:00:00","2016-07-04T00:00:00","2016-07-05T00:00:00","2016-07-06T00:00:00","2016-07-07T00:00:00","2016-07-08T00:00:00","2016-07-09T00:00:00","2016-07-10T00:00:00","2016-07-11T00:00:00","2016-07-12T00:00:00","2016-07-13T00:00:00","2016-07-14T00:00:00","2016-07-15T00:00:00","2016-07-16T00:00:00","2016-07-17T00:00:00","2016-07-18T00:00:00","2016-07-19T00:00:00","2016-07-20T00:00:00","2016-07-21T00:00:00","2016-07-22T00:00:00","2016-07-23T00:00:00","2016-07-24T00:00:00","2016-07-25T00:00:00","2016-07-26T00:00:00","2016-07-27T00:00:00","2016-07-28T00:00:00","2016-07-29T00:00:00","2016-07-30T00:00:00","2016-07-31T00:00:00","2016-08-01T00:00:00","2016-08-02T00:00:00","2016-08-03T00:00:00","2016-08-04T00:00:00","2016-08-05T00:00:00","2016-08-06T00:00:00","2016-08-07T00:00:00","2016-08-08T00:00:00","2016-08-09T00:00:00","2016-08-10T00:00:00","2016-08-11T00:00:00","2016-08-12T00:00:00","2016-08-13T00:00:00","2016-08-14T00:00:00","2016-08-15T00:00:00","2016-08-16T00:00:00","2016-08-17T00:00:00","2016-08-18T00:00:00","2016-08-19T00:00:00","2016-08-20T00:00:00","2016-08-21T00:00:00","2016-08-22T00:00:00","2016-08-23T00:00:00","2016-08-24T00:00:00","2016-08-25T00:00:00","2016-08-26T00:00:00","2016-08-27T00:00:00","2016-08-28T00:00:00","2016-08-29T00:00:00","2016-08-30T00:00:00","2016-08-31T00:00:00","2016-09-01T00:00:00","2016-09-02T00:00:00","2016-09-03T00:00:00","2016-09-04T00:00:00","2016-09-05T00:00:00","2016-09-06T00:00:00","2016-09-07T00:00:00","2016-09-08T00:00:00","2016-09-09T00:00:00","2016-09-10T00:00:00","2016-09-11T00:00:00","2016-09-12T00:00:00","2016-09-13T00:00:00","2016-09-14T00:00:00","2016-09-15T00:00:00","2016-09-16T00:00:00","2016-09-17T00:00:00","2016-09-18T00:00:00","2016-09-19T00:00:00","2016-09-20T00:00:00","2016-09-21T00:00:00","2016-09-22T00:00:00","2016-09-23T00:00:00","2016-09-24T00:00:00","2016-09-25T00:00:00","2016-09-26T00:00:00","2016-09-27T00:00:00","2016-09-28T00:00:00","2016-09-29T00:00:00","2016-09-30T00:00:00","2016-10-01T00:00:00","2016-10-02T00:00:00","2016-10-03T00:00:00","2016-10-04T00:00:00","2016-10-05T00:00:00","2016-10-06T00:00:00","2016-10-07T00:00:00","2016-10-08T00:00:00","2016-10-09T00:00:00","2016-10-10T00:00:00","2016-10-11T00:00:00","2016-10-12T00:00:00","2016-10-13T00:00:00","2016-10-14T00:00:00","2016-10-15T00:00:00","2016-10-16T00:00:00","2016-10-17T00:00:00","2016-10-18T00:00:00","2016-10-19T00:00:00","2016-10-20T00:00:00","2016-10-21T00:00:00","2016-10-22T00:00:00","2016-10-23T00:00:00","2016-10-24T00:00:00","2016-10-25T00:00:00","2016-10-26T00:00:00","2016-10-27T00:00:00","2016-10-28T00:00:00","2016-10-29T00:00:00","2016-10-30T00:00:00","2016-10-31T00:00:00","2016-11-01T00:00:00","2016-11-02T00:00:00","2016-11-03T00:00:00","2016-11-04T00:00:00","2016-11-05T00:00:00","2016-11-06T00:00:00","2016-11-07T00:00:00","2016-11-08T00:00:00","2016-11-09T00:00:00","2016-11-10T00:00:00","2016-11-11T00:00:00","2016-11-12T00:00:00","2016-11-13T00:00:00","2016-11-14T00:00:00","2016-11-15T00:00:00","2016-11-16T00:00:00","2016-11-17T00:00:00","2016-11-18T00:00:00","2016-11-19T00:00:00","2016-11-20T00:00:00","2016-11-21T00:00:00","2016-11-22T00:00:00","2016-11-23T00:00:00","2016-11-24T00:00:00","2016-11-25T00:00:00","2016-11-26T00:00:00","2016-11-27T00:00:00","2016-11-28T00:00:00","2016-11-29T00:00:00","2016-11-30T00:00:00","2016-12-01T00:00:00","2016-12-02T00:00:00","2016-12-03T00:00:00","2016-12-04T00:00:00","2016-12-05T00:00:00","2016-12-06T00:00:00","2016-12-07T00:00:00","2016-12-08T00:00:00","2016-12-09T00:00:00","2016-12-10T00:00:00","2016-12-11T00:00:00","2016-12-12T00:00:00","2016-12-13T00:00:00","2016-12-14T00:00:00","2016-12-15T00:00:00","2016-12-16T00:00:00","2016-12-17T00:00:00","2016-12-18T00:00:00","2016-12-19T00:00:00","2016-12-20T00:00:00","2016-12-21T00:00:00","2016-12-22T00:00:00","2016-12-23T00:00:00","2016-12-24T00:00:00","2016-12-25T00:00:00","2016-12-26T00:00:00","2016-12-27T00:00:00","2016-12-28T00:00:00","2016-12-29T00:00:00","2016-12-30T00:00:00","2016-12-31T00:00:00","2017-01-01T00:00:00","2017-01-02T00:00:00","2017-01-03T00:00:00","2017-01-04T00:00:00","2017-01-05T00:00:00","2017-01-06T00:00:00","2017-01-07T00:00:00","2017-01-08T00:00:00","2017-01-09T00:00:00","2017-01-10T00:00:00","2017-01-11T00:00:00","2017-01-12T00:00:00","2017-01-13T00:00:00","2017-01-14T00:00:00","2017-01-15T00:00:00","2017-01-16T00:00:00","2017-01-17T00:00:00","2017-01-18T00:00:00","2017-01-19T00:00:00","2017-01-20T00:00:00","2017-01-21T00:00:00","2017-01-22T00:00:00","2017-01-23T00:00:00","2017-01-24T00:00:00","2017-01-25T00:00:00","2017-01-26T00:00:00","2017-01-27T00:00:00","2017-01-28T00:00:00","2017-01-29T00:00:00","2017-01-30T00:00:00","2017-01-31T00:00:00","2017-02-01T00:00:00","2017-02-02T00:00:00","2017-02-03T00:00:00","2017-02-04T00:00:00","2017-02-05T00:00:00","2017-02-06T00:00:00","2017-02-07T00:00:00","2017-02-08T00:00:00","2017-02-09T00:00:00","2017-02-10T00:00:00","2017-02-11T00:00:00","2017-02-12T00:00:00","2017-02-13T00:00:00","2017-02-14T00:00:00","2017-02-15T00:00:00","2017-02-16T00:00:00","2017-02-17T00:00:00","2017-02-18T00:00:00","2017-02-19T00:00:00","2017-02-20T00:00:00","2017-02-21T00:00:00","2017-02-22T00:00:00","2017-02-23T00:00:00","2017-02-24T00:00:00","2017-02-25T00:00:00","2017-02-26T00:00:00","2017-02-27T00:00:00","2017-02-28T00:00:00","2017-03-01T00:00:00","2017-03-02T00:00:00","2017-03-03T00:00:00","2017-03-04T00:00:00","2017-03-05T00:00:00","2017-03-06T00:00:00","2017-03-07T00:00:00","2017-03-08T00:00:00","2017-03-09T00:00:00","2017-03-10T00:00:00","2017-03-11T00:00:00","2017-03-12T00:00:00","2017-03-13T00:00:00","2017-03-14T00:00:00","2017-03-15T00:00:00","2017-03-16T00:00:00","2017-03-17T00:00:00","2017-03-18T00:00:00","2017-03-19T00:00:00","2017-03-20T00:00:00","2017-03-21T00:00:00","2017-03-22T00:00:00","2017-03-23T00:00:00","2017-03-24T00:00:00","2017-03-25T00:00:00","2017-03-26T00:00:00","2017-03-27T00:00:00","2017-03-28T00:00:00","2017-03-29T00:00:00","2017-03-30T00:00:00","2017-03-31T00:00:00","2017-04-01T00:00:00","2017-04-02T00:00:00","2017-04-03T00:00:00","2017-04-04T00:00:00","2017-04-05T00:00:00","2017-04-06T00:00:00","2017-04-07T00:00:00","2017-04-08T00:00:00","2017-04-09T00:00:00","2017-04-10T00:00:00","2017-04-11T00:00:00","2017-04-12T00:00:00","2017-04-13T00:00:00","2017-04-14T00:00:00","2017-04-15T00:00:00","2017-04-16T00:00:00","2017-04-17T00:00:00","2017-04-18T00:00:00","2017-04-19T00:00:00","2017-04-20T00:00:00","2017-04-21T00:00:00","2017-04-22T00:00:00","2017-04-23T00:00:00","2017-04-24T00:00:00","2017-04-25T00:00:00","2017-04-26T00:00:00","2017-04-27T00:00:00","2017-04-28T00:00:00","2017-04-29T00:00:00","2017-04-30T00:00:00","2017-05-01T00:00:00","2017-05-02T00:00:00","2017-05-03T00:00:00","2017-05-04T00:00:00","2017-05-05T00:00:00","2017-05-06T00:00:00","2017-05-07T00:00:00","2017-05-08T00:00:00","2017-05-09T00:00:00","2017-05-10T00:00:00","2017-05-11T00:00:00","2017-05-12T00:00:00","2017-05-13T00:00:00","2017-05-14T00:00:00","2017-05-15T00:00:00","2017-05-16T00:00:00","2017-05-17T00:00:00","2017-05-18T00:00:00","2017-05-19T00:00:00","2017-05-20T00:00:00","2017-05-21T00:00:00","2017-05-22T00:00:00","2017-05-23T00:00:00","2017-05-24T00:00:00","2017-05-25T00:00:00","2017-05-26T00:00:00","2017-05-27T00:00:00","2017-05-28T00:00:00","2017-05-29T00:00:00","2017-05-30T00:00:00","2017-05-31T00:00:00","2017-06-01T00:00:00","2017-06-02T00:00:00","2017-06-03T00:00:00","2017-06-04T00:00:00","2017-06-05T00:00:00","2017-06-06T00:00:00","2017-06-07T00:00:00","2017-06-08T00:00:00","2017-06-09T00:00:00","2017-06-10T00:00:00","2017-06-11T00:00:00","2017-06-12T00:00:00","2017-06-13T00:00:00","2017-06-14T00:00:00","2017-06-15T00:00:00","2017-06-16T00:00:00","2017-06-17T00:00:00","2017-06-18T00:00:00","2017-06-19T00:00:00","2017-06-20T00:00:00","2017-06-21T00:00:00","2017-06-22T00:00:00","2017-06-23T00:00:00","2017-06-24T00:00:00","2017-06-25T00:00:00","2017-06-26T00:00:00","2017-06-27T00:00:00","2017-06-28T00:00:00","2017-06-29T00:00:00","2017-06-30T00:00:00","2017-07-01T00:00:00","2017-07-02T00:00:00","2017-07-03T00:00:00","2017-07-04T00:00:00","2017-07-05T00:00:00","2017-07-06T00:00:00","2017-07-07T00:00:00","2017-07-08T00:00:00","2017-07-09T00:00:00","2017-07-10T00:00:00","2017-07-11T00:00:00","2017-07-12T00:00:00","2017-07-13T00:00:00","2017-07-14T00:00:00","2017-07-15T00:00:00","2017-07-16T00:00:00","2017-07-17T00:00:00","2017-07-18T00:00:00","2017-07-19T00:00:00","2017-07-20T00:00:00","2017-07-21T00:00:00","2017-07-22T00:00:00","2017-07-23T00:00:00","2017-07-24T00:00:00","2017-07-25T00:00:00","2017-07-26T00:00:00","2017-07-27T00:00:00","2017-07-28T00:00:00","2017-07-29T00:00:00","2017-07-30T00:00:00","2017-07-31T00:00:00","2017-08-01T00:00:00","2017-08-02T00:00:00","2017-08-03T00:00:00","2017-08-04T00:00:00","2017-08-05T00:00:00","2017-08-06T00:00:00","2017-08-07T00:00:00","2017-08-08T00:00:00","2017-08-09T00:00:00","2017-08-10T00:00:00","2017-08-11T00:00:00","2017-08-12T00:00:00","2017-08-13T00:00:00","2017-08-14T00:00:00","2017-08-15T00:00:00","2017-08-16T00:00:00","2017-08-17T00:00:00","2017-08-18T00:00:00","2017-08-19T00:00:00","2017-08-20T00:00:00","2017-08-21T00:00:00","2017-08-22T00:00:00","2017-08-23T00:00:00","2017-08-24T00:00:00","2017-08-25T00:00:00","2017-08-26T00:00:00","2017-08-27T00:00:00","2017-08-28T00:00:00","2017-08-29T00:00:00","2017-08-30T00:00:00","2017-08-31T00:00:00","2017-09-01T00:00:00","2017-09-02T00:00:00","2017-09-03T00:00:00","2017-09-04T00:00:00","2017-09-05T00:00:00","2017-09-06T00:00:00","2017-09-07T00:00:00","2017-09-08T00:00:00","2017-09-09T00:00:00","2017-09-10T00:00:00","2017-09-11T00:00:00","2017-09-12T00:00:00","2017-09-13T00:00:00","2017-09-14T00:00:00","2017-09-15T00:00:00","2017-09-16T00:00:00","2017-09-17T00:00:00","2017-09-18T00:00:00","2017-09-19T00:00:00","2017-09-20T00:00:00","2017-09-21T00:00:00","2017-09-22T00:00:00","2017-09-23T00:00:00","2017-09-24T00:00:00","2017-09-25T00:00:00","2017-09-26T00:00:00","2017-09-27T00:00:00","2017-09-28T00:00:00","2017-09-29T00:00:00","2017-09-30T00:00:00","2017-10-01T00:00:00","2017-10-02T00:00:00","2017-10-03T00:00:00","2017-10-04T00:00:00","2017-10-05T00:00:00","2017-10-06T00:00:00","2017-10-07T00:00:00","2017-10-08T00:00:00","2017-10-09T00:00:00","2017-10-10T00:00:00","2017-10-11T00:00:00","2017-10-12T00:00:00","2017-10-13T00:00:00","2017-10-14T00:00:00","2017-10-15T00:00:00","2017-10-16T00:00:00","2017-10-17T00:00:00","2017-10-18T00:00:00","2017-10-19T00:00:00","2017-10-20T00:00:00","2017-10-21T00:00:00","2017-10-22T00:00:00","2017-10-23T00:00:00","2017-10-24T00:00:00","2017-10-25T00:00:00","2017-10-26T00:00:00","2017-10-27T00:00:00","2017-10-28T00:00:00","2017-10-29T00:00:00","2017-10-30T00:00:00","2017-10-31T00:00:00","2017-11-01T00:00:00","2017-11-02T00:00:00","2017-11-03T00:00:00","2017-11-04T00:00:00","2017-11-05T00:00:00","2017-11-06T00:00:00","2017-11-07T00:00:00","2017-11-08T00:00:00","2017-11-09T00:00:00","2017-11-10T00:00:00","2017-11-11T00:00:00","2017-11-12T00:00:00","2017-11-13T00:00:00","2017-11-14T00:00:00","2017-11-15T00:00:00","2017-11-16T00:00:00","2017-11-17T00:00:00","2017-11-18T00:00:00","2017-11-19T00:00:00","2017-11-20T00:00:00","2017-11-21T00:00:00","2017-11-22T00:00:00","2017-11-23T00:00:00","2017-11-24T00:00:00","2017-11-25T00:00:00","2017-11-26T00:00:00","2017-11-27T00:00:00","2017-11-28T00:00:00","2017-11-29T00:00:00","2017-11-30T00:00:00","2017-12-01T00:00:00","2017-12-02T00:00:00","2017-12-03T00:00:00","2017-12-04T00:00:00","2017-12-05T00:00:00","2017-12-06T00:00:00","2017-12-07T00:00:00","2017-12-08T00:00:00","2017-12-09T00:00:00","2017-12-10T00:00:00","2017-12-11T00:00:00","2017-12-12T00:00:00","2017-12-13T00:00:00","2017-12-14T00:00:00","2017-12-15T00:00:00","2017-12-16T00:00:00","2017-12-17T00:00:00","2017-12-18T00:00:00","2017-12-19T00:00:00","2017-12-20T00:00:00","2017-12-21T00:00:00","2017-12-22T00:00:00","2017-12-23T00:00:00","2017-12-24T00:00:00","2017-12-25T00:00:00","2017-12-26T00:00:00","2017-12-27T00:00:00","2017-12-28T00:00:00","2017-12-29T00:00:00","2017-12-30T00:00:00","2017-12-31T00:00:00","2018-02-14T00:00:00","2018-02-15T00:00:00","2018-02-16T00:00:00","2018-02-17T00:00:00","2018-02-18T00:00:00","2018-02-19T00:00:00"],"y":[8,2,1,5,13,24,16,10,22,11,6,14,16,25,6,12,12,2,6,10,8,7,8,8,7,25,13,11,16,10,14,2,8,20,18,14,10,13,9,12,16,7,15,8,14,10,17,16,16,18,9,7,5,2,6,9,14,11,8,10,9,7,5,9,4,1,10,12,5,18,11,8,9,10,14,2,13,2,2,1,13,9,12,7,13,7,6,6,11,8,9,14,3,2,7,12,13,13,13,14,6,7,12,14,10,14,1,1,7,17,8,13,10,11,7,8,11,8,9,9,3,3,9,9,4,5,10,9,8,10,7,7,7,11,7,5,15,5,10,3,7,4,16,8,7,8,7,5,2,3,6,5,8,5,2,8,3,8,9,6,3,9,6,5,5,6,6,4,6,4,5,4,11,9,10,5,11,12,7,13,7,8,8,4,8,8,4,8,4,6,7,7,6,11,18,5,9,15,7,9,10,13,8,13,11,10,13,9,15,9,10,8,6,8,10,10,12,13,8,10,12,4,8,5,10,10,6,12,8,12,12,11,5,7,7,11,9,5,16,7,11,11,12,9,10,15,3,10,14,20,8,5,11,11,9,10,14,8,12,10,13,11,6,7,15,6,6,3,8,10,8,7,10,33,35,31,34,30,43,44,31,29,35,29,38,39,38,36,28,35,30,44,44,35,45,35,31,24,36,35,34,39,28,33,27,38,31,39,30,29,41,28,38,42,33,31,36,31,33,53,41,39,34,37,28,30,30,41,40,40,33,37,30,35,37,35,34,32,35,29,37,34,44,35,40,39,32,42,41,35,47,32,37,39,38,36,39,35,22,25,35,23,27,37,41,24,32,40,27,37,38,32,34,27,30,35,35,39,30,26,39,29,36,33,31,30,32,28,31,34,36,34,32,25,37,26,38,31,44,44,23,28,40,34,43,42,30,29,34,32,21,35,28,33,26,33,31,25,37,44,35,28,28,21,32,34,35,31,25,33,35,30,26,33,31,31,26,42,31,23,22,32,24,22,25,20,34,26,28,20,29,33,27,30,33,29,29,22,24,19,42,28,39,29,24,25,21,25,33,32,22,31,19,23,27,30,33,23,30,31,39,29,30,33,31,31,32,30,32,36,30,23,22,38,21,38,36,29,31,26,32,30,31,31,19,28,24,15,35,30,36,23,25,27,24,27,31,34,31,40,21,26,29,35,29,34,28,34,22,38,27,33,39,33,32,35,30,30,29,42,16,24,28,34,35,41,27,35,31,39,37,44,33,34,35,42,39,33,35,34,36,37,23,32,32,41,37,37,32,37,31,34,35,37,33,25,34,38,38,37,33,39,36,37,30,25,39,48,40,41,35,32,33,32,34,36,36,37,34,37,30,17,22,24,41,23,30,28,39,25,30,27,25,44,39,33,39,26,32,37,30,40,38,26,26,37,23,33,31,33,17,10,12,15,31,32,28,27,23,21,31,41,31,31,25,32,32,29,36,36,39,36,23,35,39,38,26,38,40,33,42,37,29,37,32,24,31,32,38,35,30,35,33,32,28,41,24,37,48,33,28,34,32,30,40,31,35,25,31,16,32,32,30,27,21,30,24,40,36,39,36,41,39,42,39,35,28,32,29,32,37,37,32,38,43,23,27,39,32,39,37,40,36,28,26,32,36,39,17,23,29,30,36,31,24,34,23,17,31,30,29,26,26,29,12,26,29,30,22,20,21,22,34,30,31,32,29,21,28,26,28,29,31,28,16,18,24,40,46,36,40,23,19,31,36,37,27,30,21,18,33,19,14,26,25,16,17,21,27,25,21,31,30,22,27,35,36,38,24,18,20,28,33,31,35,38,16,23,28,24,20,34,27,18,11,28,25,30,31,32,28,16,24,20,34,27,27,14,19,27,25,17,25,28,17,19,24,23,28,32,28,27,26,39,20,33,27,27,24,29,23,21,24,21,30,17,27,35,44,35,40,22,18,33,26,27,28,32,36,25,25,27,29,25,9,26,27,14,26,22,11,13,18,24,14,26,24,19,22,22,18,11,18,16,17,23,31,23,19,17,22,23,15,18,18,28,31,29,23,27,25,15,24,21,19,15,18,18,14,25,8,23,18,24,17,21,12,15,20,19,23,22,19,14,16,22,21,22,23,14,30,24,24,26,24,15,21,12,21,22,27,24,15,15,10,25,17,15,18,23,13,14,12,20,12,4,7,15,18,24,20,18,16,19,16,17,17,23,17,17,18,17,7,16,17,14,19,8,18,16,18,11,15,18,7,13,3,7,13,15,6,20,15,10,1,9,8,7,7,3],"type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"rangeslider":{"visible":true},"rangeselector":{"buttons":[{"count":1,"label":"1m","step":"month","stepmode":"backward"},{"count":6,"label":"6m","step":"month","stepmode":"backward"},{"count":1,"label":"YTD","step":"year","stepmode":"todate"},{"count":1,"label":"1y","step":"year","stepmode":"backward"},{"step":"all"}]}},"title":{"text":"True and Fake News"},"plot_bgcolor":"rgb(248, 248, 255)","yaxis":{"title":{"text":"Value"}}},                        {"responsive": true}                    ).then(function(){
    
    var gd = document.getElementById('ebba7e91-e5e5-40db-9c6e-ef82e1299a2e');
    var x = new MutationObserver(function (mutations, observer) {{
            var display = window.getComputedStyle(gd).display;
            if (!display || display === 'none') {{
                console.log([gd, 'removed!']);
                Plotly.purge(gd);
                observer.disconnect();
            }}
    }});
    
    // Listen for the removal of the full notebook cells
    var notebookContainer = gd.closest('#notebook-container');
    if (notebookContainer) {{
        x.observe(notebookContainer, {childList: true});
    }}
    
    // Listen for the clearing of the current output cell
    var outputEl = gd.closest('.output');
    if (outputEl) {{
        x.observe(outputEl, {childList: true});
    }}
    
                            })                };                });            </script>        </div>


.. code:: ipython3

    #Extracting 'reviews' for processing
    news_features=clean_news.copy()
    news_features=news_features[['news']].reset_index(drop=True)
    news_features.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>news</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>donald trump sends embarrassing new year’s eve...</td>
        </tr>
        <tr>
          <th>1</th>
          <td>drunk bragging trump staffer started russian c...</td>
        </tr>
        <tr>
          <th>2</th>
          <td>sheriff david clarke becomes internet joke thr...</td>
        </tr>
        <tr>
          <th>3</th>
          <td>trump obsessed even obama’s name coded website...</td>
        </tr>
        <tr>
          <th>4</th>
          <td>pope francis called donald trump christmas spe...</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    stop_words = set(stopwords.words("english"))
    #Performing stemming on the review dataframe
    ps = PorterStemmer()
    
    #splitting and adding the stemmed words except stopwords
    corpus = []
    for i in range(0, len(news_features)):
        news = re.sub('[^a-zA-Z]', ' ', news_features['news'][i])
        news= news.lower()
        news = news.split()
        news = [ps.stem(word) for word in news if not word in stop_words]
        news = ' '.join(news)
        corpus.append(news)

.. code:: ipython3

    corpus[1]




.. parsed-literal::

    'drunk brag trump staffer start russian collus investigationhous intellig committe chairman devin nune go bad day assumpt like mani us christoph steeledossi prompt russia investig lash depart justic fbi order protect trump happen dossier start investig accord document obtain new york timesform trump campaign advis georg papadopoulo drunk wine bar reveal knowledg russian opposit research hillari clintonon top papadopoulo covfef boy trump administr alleg much larger role none damn drunken fool wine bar coffe boy help arrang new york meet trump presid abdel fattah elsisi egypt two month elect known former aid set meet world leader trump team trump ran mere coffe boyin may papadopoulo reveal australian diplomat alexand downer russian offici shop around possibl dirt thendemocrat presidenti nomine hillari clinton exactli much mr papadopoulo said night kensington wine room australian alexand downer unclear report state two month later leak democrat email began appear onlin australian offici pass inform mr papadopoulo american counterpart accord four current former american foreign offici direct knowledg australian role papadopoulo plead guilti lie fbi cooper wit special counsel robert mueller teamthi presid badli script realiti tv showphoto win mcnameegetti imag'



.. code:: ipython3

    tfidf_vectorizer = TfidfVectorizer(max_features=5000,ngram_range=(2,2))
    # TF-IDF feature matrix
    X= tfidf_vectorizer.fit_transform(news_features['news'])
    X.shape




.. parsed-literal::

    (44888, 5000)



.. code:: ipython3

    tfidf_vectorizer = TfidfVectorizer(max_features=5000,ngram_range=(2,2))
    # TF-IDF feature matrix
    X= tfidf_vectorizer.fit_transform(news_features['news'])
    X.shape




.. parsed-literal::

    (44888, 5000)



.. code:: ipython3

    #Getting the target variable
    y=clean_news['output']

.. code:: ipython3

    print(f'Original dataset shape : {Counter(y)}')


.. parsed-literal::

    Original dataset shape : Counter({0: 23471, 1: 21417})
    

.. code:: ipython3

    ## Divide the dataset into Train and Test
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

.. code:: ipython3

    def plot_confusion_matrix(cm, classes,
                              normalize=False,
                              title='Confusion matrix',
                              cmap=plt.cm.Blues):
        """
        This function prints and plots the confusion matrix.
        Normalization can be applied by setting `normalize=True`.
        """
        
        plt.imshow(cm, interpolation='nearest', cmap=cmap)
        plt.title(title)
        plt.colorbar()
        tick_marks = np.arange(len(classes))
        plt.xticks(tick_marks, classes, rotation=45)
        plt.yticks(tick_marks, classes)
    
        if normalize:
            cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
            print("Normalized confusion matrix")
        else:
            print('Confusion matrix, without normalization')
    
        thresh = cm.max() / 2.
        for i in range (cm.shape[0]):
            for j in range (cm.shape[1]):
                plt.text(j, i, cm[i, j],
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")
    
        plt.tight_layout()
        plt.ylabel('True label')
        plt.xlabel('Predicted label')

.. code:: ipython3

    #creating the objects
    logreg_cv = LogisticRegression(random_state=0)
    dt_cv=DecisionTreeClassifier()
    knn_cv=KNeighborsClassifier()
    nb_cv=MultinomialNB(alpha=0.1) 
    cv_dict = {0: 'Logistic Regression', 1: 'Decision Tree',2:'KNN',3:'Naive Bayes'}
    cv_models=[logreg_cv,dt_cv,knn_cv,nb_cv]
    
    #Printing the accuracy
    for i,model in enumerate(cv_models):
        print("{} Test Accuracy: {}".format(cv_dict[i],cross_val_score(model, X, y, cv=10, scoring ='accuracy').mean()))


.. parsed-literal::

    Logistic Regression Test Accuracy: 0.9660040199274997
    Decision Tree Test Accuracy: 0.9350599246563892
    KNN Test Accuracy: 0.613172841991654
    Naive Bayes Test Accuracy: 0.9373328405462511
    

.. code:: ipython3

    param_grid = {'C': np.logspace(-4, 4, 50),
                 'penalty':['l1', 'l2']}
    clf = GridSearchCV(LogisticRegression(random_state=0), param_grid,cv=5, verbose=0,n_jobs=-1)
    best_model = clf.fit(X_train,y_train)
    print(best_model.best_estimator_)
    print("The mean accuracy of the model is:",best_model.score(X_test,y_test))


.. parsed-literal::

    LogisticRegression(C=24.420530945486497, random_state=0)
    The mean accuracy of the model is: 0.9803065407235787
    

.. code:: ipython3

    logreg = LogisticRegression(C=24.420530945486497, random_state=0)
    logreg.fit(X_train, y_train)
    y_pred = logreg.predict(X_test)
    print('Accuracy of logistic regression classifier on test set: {:.2f}'.format(logreg.score(X_test, y_test)))


.. parsed-literal::

    Accuracy of logistic regression classifier on test set: 0.98
    

.. code:: ipython3

    cm = metrics.confusion_matrix(y_test, y_pred)
    plot_confusion_matrix(cm, classes=['Fake','True'])


.. parsed-literal::

    Confusion matrix, without normalization
    


.. image:: output_41_1.png


.. code:: ipython3

    print("Classification Report:\n",classification_report(y_test, y_pred))


.. parsed-literal::

    Classification Report:
                   precision    recall  f1-score   support
    
               0       0.98      0.98      0.98      5892
               1       0.98      0.98      0.98      5330
    
        accuracy                           0.98     11222
       macro avg       0.98      0.98      0.98     11222
    weighted avg       0.98      0.98      0.98     11222
    
    

.. code:: ipython3

    logit_roc_auc = roc_auc_score(y_test, logreg.predict(X_test))
    fpr, tpr, thresholds = roc_curve(y_test, logreg.predict_proba(X_test)[:,1])
    plt.figure()
    plt.plot(fpr, tpr, label='Logistic Regression (area = %0.2f)' % logit_roc_auc)
    plt.plot([0, 1], [0, 1],'r--')
    plt.xlim([-0.01, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.show()



.. image:: output_43_0.png


.. code:: ipython3

    corpus[1]




.. parsed-literal::

    'drunk brag trump staffer start russian collus investigationhous intellig committe chairman devin nune go bad day assumpt like mani us christoph steeledossi prompt russia investig lash depart justic fbi order protect trump happen dossier start investig accord document obtain new york timesform trump campaign advis georg papadopoulo drunk wine bar reveal knowledg russian opposit research hillari clintonon top papadopoulo covfef boy trump administr alleg much larger role none damn drunken fool wine bar coffe boy help arrang new york meet trump presid abdel fattah elsisi egypt two month elect known former aid set meet world leader trump team trump ran mere coffe boyin may papadopoulo reveal australian diplomat alexand downer russian offici shop around possibl dirt thendemocrat presidenti nomine hillari clinton exactli much mr papadopoulo said night kensington wine room australian alexand downer unclear report state two month later leak democrat email began appear onlin australian offici pass inform mr papadopoulo american counterpart accord four current former american foreign offici direct knowledg australian role papadopoulo plead guilti lie fbi cooper wit special counsel robert mueller teamthi presid badli script realiti tv showphoto win mcnameegetti imag'



.. code:: ipython3

    #Setting up vocabulary size
    voc_size=10000
    
    #One hot encoding 
    onehot_repr=[one_hot(words,voc_size)for words in corpus] 

.. code:: ipython3

    #Setting sentence length
    sent_length=5000
    
    #Padding the sentences
    embedded_docs=pad_sequences(onehot_repr,padding='pre',maxlen=sent_length)
    print(embedded_docs)


.. parsed-literal::

    [[   0    0    0 ... 6392 2067 7554]
     [   0    0    0 ... 8547 5943 7554]
     [   0    0    0 ... 7526 5791 7554]
     ...
     [   0    0    0 ... 7029 8152 4891]
     [   0    0    0 ... 7470 6901 5479]
     [   0    0    0 ... 4319 5939 6201]]
    

.. code:: ipython3

    embedded_docs[1]




.. parsed-literal::

    array([   0,    0,    0, ..., 8547, 5943, 7554])



.. code:: ipython3

    #Creating the lstm model
    embedding_vector_features=40
    model=Sequential()
    model.add(Embedding(voc_size,embedding_vector_features,input_length=sent_length))
    model.add(Dropout(0.3))
    model.add(LSTM(100)) #Adding 100 lstm neurons in the layer
    model.add(Dropout(0.3))
    model.add(Dense(1,activation='sigmoid'))
    
    #Compiling the model
    model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])
    print(model.summary())


.. parsed-literal::

    Model: "sequential"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     embedding (Embedding)       (None, 5000, 40)          400000    
                                                                     
     dropout (Dropout)           (None, 5000, 40)          0         
                                                                     
     lstm (LSTM)                 (None, 100)               56400     
                                                                     
     dropout_1 (Dropout)         (None, 100)               0         
                                                                     
     dense (Dense)               (None, 1)                 101       
                                                                     
    =================================================================
    Total params: 456,501
    Trainable params: 456,501
    Non-trainable params: 0
    _________________________________________________________________
    None
    

.. code:: ipython3

    len(embedded_docs),y.shape




.. parsed-literal::

    (44888, (44888,))



.. code:: ipython3

    # Converting the X and y as array
    X_final=np.array(embedded_docs)
    y_final=np.array(y)
    
    #Check shape of X and y final
    X_final.shape,y_final.shape




.. parsed-literal::

    ((44888, 5000), (44888,))



.. code:: ipython3

    # Train test split of the X and y final
    X_train, X_test, y_train, y_test = train_test_split(X_final, y_final, test_size=0.33, random_state=42)
    
    # Fitting with 10 epochs and 64 batch size
    model.fit(X_train,y_train,validation_data=(X_test,y_test),epochs=10,batch_size=64)


.. parsed-literal::

    Epoch 1/10
    462/470 [============================>.] - ETA: 10:05 - loss: 0.1997 - accuracy: 0.9212

.. code:: ipython3

    # Predicting from test data
    y_pred=model.predict_classes(X_test)
    
    #Creating confusion matrix
    #confusion_matrix(y_test,y_pred)
    cm = metrics.confusion_matrix(y_test, y_pred)
    plot_confusion_matrix(cm,classes=['Fake','True'])

.. code:: ipython3

    #Checking for accuracy
    accuracy_score(y_test,y_pred)

.. code:: ipython3

    # Creating classification report 
    print(classification_report(y_test,y_pred))

.. code:: ipython3

    # Creating bidirectional lstm model
    embedding_vector_features=40
    model1=Sequential()
    model1.add(Embedding(voc_size,embedding_vector_features,input_length=sent_length))
    model1.add(Bidirectional(LSTM(100))) # Bidirectional LSTM layer
    model1.add(Dropout(0.3))
    model1.add(Dense(1,activation='sigmoid'))
    model1.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])
    print(model1.summary())

.. code:: ipython3

    # Fitting the model
    model1.fit(X_train,y_train,validation_data=(X_test,y_test),epochs=10,batch_size=64)

.. code:: ipython3

    # Predicting from test dataset
    y_pred1=model1.predict_classes(X_test)
    
    #Confusion matrix
    cm = metrics.confusion_matrix(y_test, y_pred1)
    plot_confusion_matrix(cm,classes=['Fake','True'])

.. code:: ipython3

    #Calculating Accuracy score
    accuracy_score(y_test,y_pred1)

.. code:: ipython3

    # Creating classification report 
    print(classification_report(y_test,y_pred1))






